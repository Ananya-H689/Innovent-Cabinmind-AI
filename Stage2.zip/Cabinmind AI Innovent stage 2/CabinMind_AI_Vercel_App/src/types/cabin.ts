export type WellbeingState = 
  | 'CALM'
  | 'MILD ANXIETY'
  | 'HIGH STRESS'
  | 'DISTRESS'
  | 'DVT RISK'
  | 'DEHYDRATION RISK'
  | 'TURBULENCE DISCOMFORT';

export type SeatStatus = 'NORMAL' | 'MILD' | 'MONITOR' | 'ACTION';

export type AlertCategory = 'CRITICAL' | 'HIGH' | 'MONITOR' | 'INFO';

export type AlertStatus = 'ACTIVE' | 'ACKNOWLEDGED' | 'ASSIGNED' | 'RESOLVED';

export interface TelemetryData {
  heartRate: number; // bpm
  hrv: number; // ms
  gsr: number; // uS
  movement: number; // g-force / activity index 0-10
  seatPressure: { left: number; right: number; back: number }; // kPa
  posture: 'Balanced' | 'Slouched' | 'Restless' | 'Rigid';
  temp: number; // °C
  immobilityHours: number;
  hrHistory: number[];
  hrvHistory: number[];
  gsrHistory: number[];
}

export interface SeatData {
  id: string; // e.g., "14A"
  row: number;
  letter: 'A' | 'B' | 'C' | 'D' | 'E' | 'F';
  passengerName: string;
  age: number;
  gender: 'M' | 'F' | 'Other';
  flightClass: 'Business' | 'Economy';
  status: SeatStatus;
  wellbeing: WellbeingState;
  riskScore: number; // 0-100
  confidence: number; // %
  dvtScore: number;
  dehydrationScore: number;
  stressScore: number;
  comfortScore: number;
  telemetry: TelemetryData;
  aiInsight: string;
  recommendedAction: string;
  lastUpdated: string;
}

export interface AlertItem {
  id: string;
  timestamp: string;
  seatId: string;
  passengerName: string;
  category: AlertCategory;
  event: string;
  riskScore: number;
  confidence: number;
  recommendedAction: string;
  status: AlertStatus;
  assignedCrew: string | null;
}

export type TurbulenceStage = 'NORMAL' | 'T-12' | 'T-8' | 'T-4' | 'T-0';

export interface TurbulenceState {
  status: 'CLEAR' | 'PREDICTED' | 'PREPARING' | 'ADAPTING' | 'ACTIVE_TURBULENCE';
  minutesRemaining: number;
  intensity: 'Light' | 'Moderate' | 'Severe';
  confidence: number;
  activeStage: TurbulenceStage;
  stageMessage: string;
}

export interface CabinAdaptationState {
  lighting: string;
  airflow: string;
  audio: string;
  seatbeltAlert: boolean;
  crewReadiness: 'STANDARD' | 'ELEVATED' | 'IMMINENT';
}

export interface FlightInfo {
  flightNumber: string;
  aircraft: string;
  route: string;
  origin: string;
  destination: string;
  altitude: string;
  speed: string;
  phase: 'TAXI' | 'CLIMB' | 'CRUISE' | 'DESCENT' | 'LANDING';
  flightTimeElapsed: string;
  flightTimeTotal: string;
  cabinTemp: number;
  cabinHumidity: number;
  cabinPressure: number;
  aiEngineStatus: string;
  connectivity: string;
}

export type RoutePath = '/' | '/crew' | '/passenger' | '/analytics' | '/hardware' | '/engine';
