import React from 'react';
import { SimulationProvider, useCabinSimulation } from './context/SimulationContext';
import { Navbar } from './components/Navbar';
import { DemoControlCenter } from './components/DemoControlCenter';
import { LandingView } from './views/LandingView';
import { CrewView } from './views/CrewView';
import { PassengerView } from './views/PassengerView';
import { AnalyticsView } from './views/AnalyticsView';
import { HardwareView } from './views/HardwareView';
import { EngineView } from './views/EngineView';

const MainContent: React.FC = () => {
  const { currentRoute } = useCabinSimulation();

  const renderView = () => {
    switch (currentRoute) {
      case '/crew':
        return <CrewView />;
      case '/passenger':
        return <PassengerView />;
      case '/analytics':
        return <AnalyticsView />;
      case '/hardware':
        return <HardwareView />;
      case '/engine':
        return <EngineView />;
      case '/':
      default:
        return <LandingView />;
    }
  };

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 min-h-[calc(100vh-160px)]">
      {renderView()}
    </main>
  );
};

export function App() {
  return (
    <SimulationProvider>
      <div className="min-h-screen bg-[#070B14] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200 relative">
        <Navbar />
        <MainContent />
        <DemoControlCenter />

        {/* Global Footer */}
        <footer className="w-full border-t border-white/5 py-8 text-center text-xs font-mono text-slate-500 space-y-2 mt-auto pb-28">
          <p>© 2026 CABINMIND AI • Tata Technologies InnoVent-27 Concept Presentation</p>
          <p className="text-[10px] text-slate-600">
            SIMULATION MODE ACTIVE • Standalone Browser-Based Edge AI Architecture • Drag & Drop Vercel Ready
          </p>
        </footer>
      </div>
    </SimulationProvider>
  );
}

export default App;
