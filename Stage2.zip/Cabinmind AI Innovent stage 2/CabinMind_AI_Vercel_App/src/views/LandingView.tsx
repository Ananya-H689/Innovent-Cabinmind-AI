import React from 'react';
import { useCabinSimulation } from '../context/SimulationContext';
import { motion } from 'framer-motion';
import { 
  Activity, 
  Cpu, 
  ArrowRight, 
  Lock, 
  CheckCircle2, 
  Layers, 
  Radio 
} from 'lucide-react';

export const LandingView: React.FC = () => {
  const { navigate } = useCabinSimulation();

  return (
    <div className="space-y-24 pb-20">
      
      {/* HERO SECTION */}
      <section className="relative pt-12 pb-16 overflow-hidden">
        
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-cyan-500/10 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute top-10 left-1/2 -translate-x-1/2 w-96 h-96 border border-cyan-500/15 rounded-full pointer-events-none animate-radar opacity-40" />

        <div className="max-w-5xl mx-auto text-center space-y-8 relative z-10">
          
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-400/30 text-cyan-300 text-xs font-mono font-semibold"
          >
            <Radio className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            <span>TATA TECHNOLOGIES INNOVENT-27 FLAGSHIP CONCEPT</span>
            <span className="bg-cyan-500/20 px-2 py-0.5 rounded text-[10px] text-cyan-200">SIMULATION MODE</span>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
            className="space-y-4"
          >
            <h1 className="text-5xl sm:text-7xl font-extrabold tracking-tight text-white font-heading">
              CABINMIND <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-teal-300 to-blue-500">AI</span>
            </h1>
            
            <p className="text-2xl sm:text-3xl font-heading font-light text-slate-200 tracking-wide max-w-3xl mx-auto">
              Where Every Seat Thinks. <span className="text-cyan-400 font-normal">Every Journey Cares.</span>
            </p>
          </motion.div>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed"
          >
            An embedded Edge AI platform transforming aircraft cabins into intelligent, passenger-centric wellbeing ecosystems. Sensing physiological stress, predicting discomfort 12 minutes ahead, and adapting cabin environments autonomously.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4"
          >
            <button
              onClick={() => navigate('/crew')}
              className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-heading text-base font-bold hover:from-cyan-400 hover:to-blue-500 shadow-xl shadow-cyan-500/25 transition-all flex items-center justify-center space-x-3 group"
            >
              <Activity className="w-5 h-5 text-slate-950" />
              <span>LAUNCH CREW COMMAND CENTER</span>
              <ArrowRight className="w-5 h-5 text-slate-950 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={() => navigate('/hardware')}
              className="w-full sm:w-auto px-6 py-4 rounded-xl glass-panel text-slate-200 font-heading text-base font-semibold hover:text-white hover:border-cyan-500/50 transition-all flex items-center justify-center space-x-2"
            >
              <Cpu className="w-5 h-5 text-cyan-400" />
              <span>EXPLORE DIGITAL TWIN</span>
            </button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="pt-8 max-w-4xl mx-auto"
          >
            <div className="glass-panel p-6 rounded-3xl border border-cyan-500/30 shadow-2xl relative overflow-hidden bg-slate-950/80">
              <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-4 text-xs font-mono text-slate-400">
                <span className="flex items-center space-x-2">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                  <span className="text-cyan-300 font-bold">AIRBUS A320neo LIVE CABIN NETWORK SIMULATION</span>
                </span>
                <span>EDGE TPU • 14 TOPS INFERENCE</span>
              </div>

              <div className="grid grid-cols-6 gap-3 py-6 px-4 bg-slate-900/60 rounded-2xl border border-slate-800">
                {[
                  { seat: '12A', status: 'CALM', hr: 68, color: 'border-emerald-500/50 text-emerald-300' },
                  { seat: '12B', status: 'CALM', hr: 72, color: 'border-emerald-500/50 text-emerald-300' },
                  { seat: '13C', status: 'HYDRATION', hr: 84, color: 'border-cyan-400/60 text-cyan-300' },
                  { seat: '14A', status: 'STRESS', hr: 118, color: 'border-rose-500/80 text-rose-300 glow-red animate-pulse' },
                  { seat: '15D', status: 'CALM', hr: 69, color: 'border-emerald-500/50 text-emerald-300' },
                  { seat: '16F', status: 'DVT RISK', hr: 74, color: 'border-amber-500/80 text-amber-300 glow-amber' },
                ].map((s) => (
                  <div key={s.seat} className={`p-3 rounded-xl border bg-slate-950/60 font-mono text-center space-y-1 ${s.color}`}>
                    <span className="text-xs font-bold block">{s.seat}</span>
                    <span className="text-[10px] block opacity-80">{s.status}</span>
                    <span className="text-[11px] font-bold block">{s.hr} bpm</span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>

        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4">
        <div className="text-center space-y-3 mb-12">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-heading">
            SENSE → PREDICT → ADAPT
          </h2>
          <p className="text-slate-400 text-sm max-w-xl mx-auto">
            The closed-loop intelligent aircraft cabin workflow designed for Tata Technologies InnoVent-27.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          <div className="glass-panel-interactive p-6 rounded-2xl border border-white/10 space-y-4">
            <div className="w-12 h-12 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-400 font-mono font-bold text-lg">
              01
            </div>
            <h3 className="text-xl font-bold text-white font-heading">SENSE</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Non-intrusive seat-embedded sensors continuously capture Heart Rate Variability (HRV), Galvanic Skin Response (GSR), seat pressure distribution, posture shifts, movement, and flight IMU telemetry passively without wearables.
            </p>
            <ul className="text-xs font-mono text-cyan-300 space-y-1 pt-2">
              <li className="flex items-center space-x-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>Piezoelectric Pressure Array</span>
              </li>
              <li className="flex items-center space-x-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>Micro-GSR Armrest Sensors</span>
              </li>
              <li className="flex items-center space-x-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>Non-Contact PPG Headrest</span>
              </li>
            </ul>
          </div>

          <div className="glass-panel-interactive p-6 rounded-2xl border border-white/10 space-y-4">
            <div className="w-12 h-12 rounded-xl bg-purple-500/20 border border-purple-400/40 flex items-center justify-center text-purple-400 font-mono font-bold text-lg">
              02
            </div>
            <h3 className="text-xl font-bold text-white font-heading">PREDICT</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Local onboard Edge AI engines perform multi-modal sensor fusion to detect early physiological signs of stress, panic events, DVT risk from prolonged immobility, dermal dehydration, and predictive 12-minute turbulence response.
            </p>
            <ul className="text-xs font-mono text-purple-300 space-y-1 pt-2">
              <li className="flex items-center space-x-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-purple-400" />
                <span>XGBoost & LSTM Inference</span>
              </li>
              <li className="flex items-center space-x-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-purple-400" />
                <span>12-Min Turbulence Window</span>
              </li>
              <li className="flex items-center space-x-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-purple-400" />
                <span>Immobility & DVT Risk Engine</span>
              </li>
            </ul>
          </div>

          <div className="glass-panel-interactive p-6 rounded-2xl border border-white/10 space-y-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-400 font-mono font-bold text-lg">
              03
            </div>
            <h3 className="text-xl font-bold text-white font-heading">ADAPT</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Autonomous cabin environment adaptation (warm ambient lighting, +8% oxygen airflow, 432Hz calming audio) paired with discreet crew decision support alerts containing seat number, risk level, and suggested actions.
            </p>
            <ul className="text-xs font-mono text-emerald-300 space-y-1 pt-2">
              <li className="flex items-center space-x-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Discreet Crew Mobile Alerts</span>
              </li>
              <li className="flex items-center space-x-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Automated Lighting & Airflow</span>
              </li>
              <li className="flex items-center space-x-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Post-Flight Fatigue Recovery</span>
              </li>
            </ul>
          </div>

        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-8">
        
        <div className="glass-panel p-8 rounded-3xl border border-cyan-500/20 space-y-4">
          <div className="flex items-center space-x-3">
            <div className="p-3 rounded-2xl bg-cyan-500/20 border border-cyan-400/30 text-cyan-400">
              <Lock className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white font-heading">PRIVACY BY DESIGN</h3>
              <p className="text-xs text-slate-400">Zero Raw Biometric Cloud Upload</p>
            </div>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            All physiological data processing, feature extraction, and ML inference are executed 100% locally on the onboard Edge AI Gateway. Raw sensor streams are wiped immediately after feature calculation, ensuring strict compliance with aviation privacy regulations and GDPR.
          </p>
        </div>

        <div className="glass-panel p-8 rounded-3xl border border-purple-500/20 space-y-4">
          <div className="flex items-center space-x-3">
            <div className="p-3 rounded-2xl bg-purple-500/20 border border-purple-400/30 text-purple-400">
              <Layers className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white font-heading">EMBEDDED ARCHITECTURE</h3>
              <p className="text-xs text-slate-400">Low-Latency Aerospace Computing</p>
            </div>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Built using TypeScript, Vite, React, Framer Motion, and custom browser-side Edge AI inference engine. Modular architecture allows seamless drop-in replacement with AWS IoT Core / SageMaker cloud analytics pipelines.
          </p>
        </div>

      </section>

      <section className="max-w-4xl mx-auto text-center px-4">
        <div className="glass-panel p-10 rounded-3xl border border-cyan-500/30 space-y-6 bg-gradient-to-b from-slate-900/90 to-slate-950/90">
          <h2 className="text-3xl font-extrabold text-white font-heading">
            Ready to Experience the Intelligent Aircraft Cabin?
          </h2>
          <p className="text-slate-300 text-sm max-w-lg mx-auto">
            Test the live 36-seat crew command center, trigger stress & turbulence events, and explore passenger recovery workflows.
          </p>
          <button
            onClick={() => navigate('/crew')}
            className="px-8 py-4 rounded-xl bg-cyan-500 text-slate-950 font-heading text-base font-bold hover:bg-cyan-400 shadow-xl shadow-cyan-500/25 transition-all inline-flex items-center space-x-2"
          >
            <span>ENTER CREW OPERATIONS DEMO</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </section>

    </div>
  );
};
