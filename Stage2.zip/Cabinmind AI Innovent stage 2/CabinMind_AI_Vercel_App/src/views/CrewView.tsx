import React from 'react';
import { useCabinSimulation } from '../context/SimulationContext';
import { AnalyticsOverviewCards } from '../components/AnalyticsOverviewCards';
import { SeatMap3D } from '../components/SeatMap3D';
import { PassengerDetailPanel } from '../components/PassengerDetailPanel';
import { AlertCenter } from '../components/AlertCenter';
import { TurbulenceWidget } from '../components/TurbulenceWidget';
import { CabinAdaptationWidget } from '../components/CabinAdaptationWidget';
import { 
  Activity, 
  Wifi, 
  Cpu, 
  Radio 
} from 'lucide-react';

export const CrewView: React.FC = () => {
  const { flightInfo } = useCabinSimulation();

  return (
    <div className="space-y-8 pb-24">
      
      <div className="glass-panel p-6 rounded-2xl border border-cyan-500/30 relative overflow-hidden bg-gradient-to-r from-slate-950/90 via-slate-900/90 to-slate-950/90">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          
          <div className="flex items-start space-x-4">
            <div className="p-3 rounded-2xl bg-cyan-500/20 border border-cyan-400/40 text-cyan-400 shadow-lg shadow-cyan-500/20">
              <Activity className="w-8 h-8 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="font-heading text-2xl sm:text-3xl font-extrabold text-white tracking-wide">
                  CABINMIND AI CREW OPERATIONS
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">
                  FLAGSHIP COMMAND CENTER
                </span>
              </div>
              <p className="text-xs text-slate-300 font-mono mt-1 flex items-center space-x-2">
                <span>InnoVent-27 Real-time Aircraft Cabin Intelligence</span>
                <span className="text-slate-600">•</span>
                <span className="text-emerald-400 flex items-center space-x-1">
                  <Radio className="w-3 h-3 inline animate-ping" />
                  <span>SIMULATION ACTIVE</span>
                </span>
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
            
            <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
              <span className="text-slate-400 block text-[10px]">FLIGHT / ROUTE</span>
              <span className="text-cyan-300 font-bold block">{flightInfo.flightNumber}</span>
              <span className="text-slate-300 text-[11px]">{flightInfo.route}</span>
            </div>

            <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
              <span className="text-slate-400 block text-[10px]">AIRCRAFT / ALT</span>
              <span className="text-white font-bold block">{flightInfo.aircraft.split(' ')[0]} {flightInfo.aircraft.split(' ')[1]}</span>
              <span className="text-cyan-400 text-[11px]">{flightInfo.altitude} • {flightInfo.phase}</span>
            </div>

            <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
              <span className="text-slate-400 block text-[10px]">AI ENGINE STATUS</span>
              <span className="text-emerald-400 font-bold flex items-center space-x-1">
                <Cpu className="w-3 h-3 text-emerald-400" />
                <span>EDGE TPU ACTIVE</span>
              </span>
              <span className="text-slate-400 text-[10px]">14 TOPS Inference</span>
            </div>

            <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
              <span className="text-slate-400 block text-[10px]">CONNECTIVITY</span>
              <span className="text-cyan-300 font-bold flex items-center space-x-1">
                <Wifi className="w-3 h-3 text-cyan-400" />
                <span>SATCOM 32ms</span>
              </span>
              <span className="text-slate-400 text-[10px]">Local Edge Priority</span>
            </div>

          </div>

        </div>
      </div>

      <AnalyticsOverviewCards />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-6 xl:col-span-7">
          <SeatMap3D />
        </div>

        <div className="lg:col-span-6 xl:col-span-5">
          <PassengerDetailPanel />
        </div>
      </div>

      <TurbulenceWidget />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-6">
          <CabinAdaptationWidget />
        </div>

        <div className="lg:col-span-6">
          <AlertCenter />
        </div>
      </div>

    </div>
  );
};
