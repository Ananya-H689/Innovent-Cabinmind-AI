import React, { useState } from 'react';
import { useCabinSimulation } from '../context/SimulationContext';
import { calculatePassengerRisk, DEFAULT_RISK_WEIGHTS } from '../utils/riskEngine';
import type { RiskWeights } from '../utils/riskEngine';
import { Sliders, Zap, Sparkles, CheckCircle2 } from 'lucide-react';

export const EngineView: React.FC = () => {
  const { selectedSeat } = useCabinSimulation();

  const [weights] = useState<RiskWeights>(DEFAULT_RISK_WEIGHTS);

  const [testHR, setTestHR] = useState<number>(selectedSeat?.telemetry.heartRate || 108);
  const [testHRV, setTestHRV] = useState<number>(selectedSeat?.telemetry.hrv || 22);
  const [testGSR, setTestGSR] = useState<number>(selectedSeat?.telemetry.gsr || 14.2);
  const [testImmobility, setTestImmobility] = useState<number>(selectedSeat?.telemetry.immobilityHours || 3.8);
  const [testTemp] = useState<number>(selectedSeat?.telemetry.temp || 37.4);

  const testTelemetry = {
    heartRate: testHR,
    hrv: testHRV,
    gsr: testGSR,
    movement: 0.8,
    seatPressure: { left: 62, right: 30, back: 50 },
    posture: 'Slouched' as const,
    temp: testTemp,
    immobilityHours: testImmobility,
    hrHistory: [testHR],
    hrvHistory: [testHRV],
    gsrHistory: [testGSR],
  };

  const riskResult = calculatePassengerRisk(testTelemetry, weights);

  return (
    <div className="space-y-8 pb-24">
      
      <div className="glass-panel p-6 rounded-2xl border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-3 rounded-2xl bg-cyan-500/20 border border-cyan-400/30 text-cyan-400">
            <Sliders className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="font-heading text-2xl font-bold text-white tracking-wide">
                CABINMIND EDGE AI RISK ENGINE SPECIFICATIONS & SANDBOX
              </h1>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">
                MODULAR JS / ML INFERENCE
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono">
              Transparent feature weights, mathematical formulas, classification matrix & natural reasoning generator
            </p>
          </div>
        </div>
      </div>

      <div className="glass-panel p-6 rounded-2xl border border-white/10 space-y-3">
        <h3 className="font-heading text-sm font-bold text-white font-mono uppercase tracking-wider">
          CLASSIFICATION MATRIX (0 - 100 NORMALIZED SCORE)
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs text-center">
          <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300">
            <span className="block font-bold text-sm">0 – 30</span>
            <span className="block text-[10px] text-slate-400 uppercase">NORMAL</span>
          </div>

          <div className="p-3 rounded-xl bg-yellow-500/10 border border-yellow-500/30 text-yellow-300">
            <span className="block font-bold text-sm">31 – 55</span>
            <span className="block text-[10px] text-slate-400 uppercase">MILD</span>
          </div>

          <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300">
            <span className="block font-bold text-sm">56 – 75</span>
            <span className="block text-[10px] text-slate-400 uppercase">MONITOR</span>
          </div>

          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 glow-red">
            <span className="block font-bold text-sm">76 – 100</span>
            <span className="block text-[10px] text-slate-400 uppercase">ACTION</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <div className="lg:col-span-6 glass-panel p-6 rounded-2xl border border-white/10 space-y-6">
          <h3 className="font-heading text-lg font-bold text-white flex items-center space-x-2">
            <Sliders className="w-5 h-5 text-cyan-400" />
            <span>INTERACTIVE SENSOR INPUT & WEIGHT TUNER</span>
          </h3>

          <div className="space-y-4 text-xs font-mono">
            <div>
              <div className="flex justify-between text-slate-300 font-bold mb-1">
                <span>Heart Rate (HR): {testHR} BPM</span>
                <span className="text-slate-500">(Normal: 60-80)</span>
              </div>
              <input type="range" min="50" max="140" value={testHR} onChange={(e) => setTestHR(Number(e.target.value))} className="w-full accent-cyan-400" />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 font-bold mb-1">
                <span>Heart Rate Variability (HRV): {testHRV} MS</span>
                <span className="text-slate-500">(Higher = Calmer)</span>
              </div>
              <input type="range" min="10" max="90" value={testHRV} onChange={(e) => setTestHRV(Number(e.target.value))} className="w-full accent-cyan-400" />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 font-bold mb-1">
                <span>Galvanic Skin Response (GSR): {testGSR} µS</span>
                <span className="text-slate-500">(Elevated = Stress)</span>
              </div>
              <input type="range" min="1" max="25" step="0.5" value={testGSR} onChange={(e) => setTestGSR(Number(e.target.value))} className="w-full accent-purple-400" />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 font-bold mb-1">
                <span>Immobility Duration: {testImmobility} Hours</span>
                <span className="text-slate-500">(&gt;3h = DVT Risk)</span>
              </div>
              <input type="range" min="0" max="6" step="0.2" value={testImmobility} onChange={(e) => setTestImmobility(Number(e.target.value))} className="w-full accent-amber-400" />
            </div>
          </div>
        </div>

        <div className="lg:col-span-6 glass-panel p-6 rounded-2xl border border-cyan-500/30 space-y-6">
          <h3 className="font-heading text-lg font-bold text-white flex items-center space-x-2">
            <Zap className="w-5 h-5 text-cyan-400" />
            <span>REAL-TIME INFERENCE OUTPUT & TRANSPARENT REASONING</span>
          </h3>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-center">
            <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
              <span className="text-[10px] text-slate-400 block">STRESS SCORE</span>
              <span className="text-xl font-bold text-rose-400">{riskResult.stressScore}/100</span>
            </div>

            <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
              <span className="text-[10px] text-slate-400 block">DVT RISK SCORE</span>
              <span className="text-xl font-bold text-amber-400">{riskResult.dvtScore}/100</span>
            </div>

            <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
              <span className="text-[10px] text-slate-400 block">DEHYDRATION</span>
              <span className="text-xl font-bold text-cyan-400">{riskResult.dehydrationScore}/100</span>
            </div>

            <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
              <span className="text-[10px] text-slate-400 block">COMFORT SCORE</span>
              <span className="text-xl font-bold text-emerald-400">{riskResult.comfortScore}/100</span>
            </div>
          </div>

          <div className="flex items-center justify-between bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono">
            <div>
              <span className="text-slate-400 text-[10px] block">CLASSIFIED STATUS</span>
              <span className="text-cyan-300 font-bold text-base">{riskResult.status}</span>
            </div>

            <div className="text-right">
              <span className="text-slate-400 text-[10px] block">WELLBEING LABEL</span>
              <span className="text-purple-300 font-bold text-base">{riskResult.wellbeing}</span>
            </div>
          </div>

          <div className="bg-cyan-950/20 border border-cyan-500/30 p-4 rounded-xl space-y-2">
            <div className="flex items-center space-x-2 text-cyan-300 text-xs font-mono font-bold">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>GENERATED AI INSIGHT</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed font-mono">
              "{riskResult.aiInsight}"
            </p>
          </div>

          <div className="bg-emerald-950/20 border border-emerald-500/30 p-4 rounded-xl space-y-2">
            <div className="flex items-center space-x-2 text-emerald-300 text-xs font-mono font-bold">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>DECISION SUPPORT RECOMMENDED ACTION</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed font-mono font-bold">
              "{riskResult.recommendedAction}"
            </p>
          </div>

        </div>

      </div>

    </div>
  );
};
