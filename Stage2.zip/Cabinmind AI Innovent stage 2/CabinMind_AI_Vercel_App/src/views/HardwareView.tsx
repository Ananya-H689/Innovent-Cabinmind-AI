import React, { useState, useEffect } from 'react';
import { useCabinSimulation } from '../context/SimulationContext';
import { 
  Cpu, 
  Layers, 
  Radio, 
  Activity, 
  Zap, 
  ShieldCheck, 
  Server, 
  ArrowRight, 
  Terminal,
  CheckCircle2
} from 'lucide-react';

export const HardwareView: React.FC = () => {
  const { isRunning, speed } = useCabinSimulation();

  const [busPackets, setBusPackets] = useState<string[]>([]);

  useEffect(() => {
    if (!isRunning) return;

    const interval = setInterval(() => {
      const now = new Date().toISOString().slice(11, 23);
      const hexId = Math.floor(Math.random() * 0xFFF).toString(16).toUpperCase().padStart(3, '0');
      const hrvHex = Math.floor(40 + Math.random() * 40).toString(16).toUpperCase();
      const gsrHex = Math.floor(20 + Math.random() * 80).toString(16).toUpperCase();
      const pressureHex = Math.floor(100 + Math.random() * 150).toString(16).toUpperCase();
      
      const packet = `[${now}] CAN-BUS SEAT_${hexId} | HRV:0x${hrvHex} GSR:0x${gsrHex} PRESS:0x${pressureHex} CRC:OK`;

      setBusPackets(prev => [packet, ...prev.slice(0, 14)]);
    }, 600 / speed);

    return () => clearInterval(interval);
  }, [isRunning, speed]);

  const pipelineSteps = [
    { id: '1', title: 'Passenger Sensors', desc: 'Embedded Piezo Seat Grid, GSR Armrest, PPG Headrest', icon: Activity, color: 'text-cyan-400 border-cyan-500/40 bg-cyan-500/10' },
    { id: '2', title: 'Seat Edge Device', desc: 'BLE/CAN Microcontroller & ADC Sampler (100Hz)', icon: Cpu, color: 'text-purple-400 border-purple-500/40 bg-purple-500/10' },
    { id: '3', title: 'Cabin Gateway', desc: 'ARINC-429 & Ethernet Onboard Bus Concentrator', icon: Server, color: 'text-blue-400 border-blue-500/40 bg-blue-500/10' },
    { id: '4', title: 'AI Risk Engine', desc: 'Edge TPU (14 TOPS) Multi-Modal Sensor Fusion Inference', icon: Zap, color: 'text-amber-400 border-amber-500/40 bg-amber-500/10' },
    { id: '5', title: 'Crew Intelligence', desc: 'Real-Time Operational Command Dashboard & Mobile Alerts', icon: ShieldCheck, color: 'text-rose-400 border-rose-500/40 bg-rose-500/10' },
    { id: '6', title: 'Passenger Experience', desc: 'Pre-Calming Environment Adaptation & Recovery Guide', icon: CheckCircle2, color: 'text-emerald-400 border-emerald-500/40 bg-emerald-500/10' },
  ];

  return (
    <div className="space-y-8 pb-24">
      
      <div className="glass-panel p-6 rounded-2xl border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-3 rounded-2xl bg-cyan-500/20 border border-cyan-400/30 text-cyan-400">
            <Cpu className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="font-heading text-2xl font-bold text-white tracking-wide">
                CABINMIND DIGITAL TWIN & HARDWARE ARCHITECTURE
              </h1>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-400/30">
                HARDWARE SIMULATION MODE
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono">
              Tata Technologies InnoVent-27 Embedded System Specification
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 px-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs font-mono text-emerald-400">
          <Radio className="w-3.5 h-3.5 animate-pulse" />
          <span>CAN-BUS BUS FREQ: 100 Hz</span>
        </div>
      </div>

      <div className="glass-panel p-8 rounded-3xl border border-cyan-500/30 space-y-6">
        <h3 className="font-heading text-lg font-bold text-white flex items-center space-x-2">
          <Layers className="w-5 h-5 text-cyan-400" />
          <span>END-TO-END EMBEDDED SYSTEM SIGNAL PIPELINE</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 xl:grid-cols-6 gap-4 relative">
          {pipelineSteps.map((step, idx) => {
            const Icon = step.icon;
            return (
              <div key={step.id} className="relative group">
                <div className={`p-4 rounded-2xl border flex flex-col justify-between h-full space-y-3 transition-all ${step.color}`}>
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold opacity-60">0{step.id}</span>
                    <Icon className="w-5 h-5" />
                  </div>

                  <div>
                    <h4 className="font-heading text-sm font-bold text-white mb-1">
                      {step.title}
                    </h4>
                    <p className="text-[11px] text-slate-300 leading-tight">
                      {step.desc}
                    </p>
                  </div>
                </div>

                {idx < pipelineSteps.length - 1 && (
                  <div className="hidden xl:block absolute -right-3 top-1/2 -translate-y-1/2 z-10 text-cyan-500/40 pointer-events-none">
                    <ArrowRight className="w-5 h-5" />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <div className="lg:col-span-6 glass-panel p-6 rounded-2xl border border-white/10 space-y-4">
          <h3 className="font-heading text-lg font-bold text-white">
            HARDWARE SENSOR SPECIFICATIONS
          </h3>

          <div className="space-y-3 text-xs font-mono">
            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
              <span className="text-cyan-400 font-bold block">1. PIEZOELECTRIC SEAT PRESSURE GRID</span>
              <p className="text-slate-300 text-[11px]">16-point resistive pressure array embedded beneath cushion foam for posture tracking & immobility duration.</p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
              <span className="text-purple-400 font-bold block">2. MICRO-GSR ARMREST ELECTRODES</span>
              <p className="text-slate-300 text-[11px]">Textile-integrated conductive fabric capturing galvanic skin conductance (0.1 - 25.0 µS) for emotional arousal.</p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
              <span className="text-emerald-400 font-bold block">3. NON-CONTACT PPG HEADREST ARRAY</span>
              <p className="text-slate-300 text-[11px]">Infrared reflective optical pulse sensor monitoring heart rate & beat-to-beat HRV interval without contact.</p>
            </div>
          </div>
        </div>

        <div className="lg:col-span-6 glass-panel p-6 rounded-2xl border border-cyan-500/30 space-y-4 bg-slate-950/90 font-mono">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <span className="text-xs text-cyan-400 font-bold flex items-center space-x-2">
              <Terminal className="w-4 h-4 text-cyan-400" />
              <span>LIVE CAN-BUS TELEMETRY PACKET STREAM</span>
            </span>
            <span className="text-[10px] text-emerald-400">100 FPS SIMULATED</span>
          </div>

          <div className="h-56 overflow-y-auto space-y-1 text-[11px] text-slate-300">
            {busPackets.map((pkt, i) => (
              <div key={i} className="hover:text-cyan-300 transition-colors">
                {pkt}
              </div>
            ))}
          </div>

          <p className="text-[10px] text-slate-500 pt-2 italic border-t border-white/5">
            * Hardware Simulation Mode. Demonstrates signals without requiring physical aircraft wiring harness.
          </p>
        </div>

      </div>

    </div>
  );
};
