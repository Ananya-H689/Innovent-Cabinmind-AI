import React, { useState } from 'react';
import { useCabinSimulation } from '../context/SimulationContext';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  Legend 
} from 'recharts';
import { BarChart3, Filter } from 'lucide-react';

export const AnalyticsView: React.FC = () => {
  const { seats } = useCabinSimulation();
  const [filterSeverity, setFilterSeverity] = useState<string>('ALL');

  const riskDistributionData = [
    { name: 'NORMAL', count: seats.filter(s => s.status === 'NORMAL').length, color: '#10B981' },
    { name: 'MILD', count: seats.filter(s => s.status === 'MILD').length, color: '#FACC15' },
    { name: 'MONITOR', count: seats.filter(s => s.status === 'MONITOR').length, color: '#F59E0B' },
    { name: 'ACTION', count: seats.filter(s => s.status === 'ACTION').length, color: '#EF4444' },
  ];

  const stressTimelineData = [
    { time: '14:00', avgStress: 22, maxStress: 45, comfort: 92 },
    { time: '14:10', avgStress: 28, maxStress: 58, comfort: 89 },
    { time: '14:20', avgStress: 35, maxStress: 78, comfort: 84 },
    { time: '14:30', avgStress: 42, maxStress: 92, comfort: 79 },
    { time: '14:40', avgStress: 31, maxStress: 65, comfort: 86 },
    { time: '14:50', avgStress: 24, maxStress: 48, comfort: 91 },
  ];

  const seatRiskMapData = seats.map(s => ({
    seat: s.id,
    riskScore: s.riskScore,
    stress: s.stressScore,
    dvt: s.dvtScore,
    dehydration: s.dehydrationScore,
  }));

  const responseTimeData = [
    { intervention: 'ACUTE ANXIETY', timeSec: 42 },
    { intervention: 'DVT STRETCH', timeSec: 68 },
    { intervention: 'DEHYDRATION CART', timeSec: 95 },
    { intervention: 'TURBULENCE PREP', timeSec: 18 },
  ];

  return (
    <div className="space-y-8 pb-24">
      
      <div className="glass-panel p-6 rounded-2xl border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-3 rounded-2xl bg-cyan-500/20 border border-cyan-400/30 text-cyan-400">
            <BarChart3 className="w-6 h-6" />
          </div>
          <div>
            <h1 className="font-heading text-2xl font-bold text-white tracking-wide">
              FLEET & CABIN WELLBEING ANALYTICS
            </h1>
            <p className="text-xs text-slate-400 font-mono">
              Flight CM-427 • Live Edge AI Sensor Fusion Telemetry Analysis
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 bg-slate-900/80 p-1.5 rounded-xl border border-slate-800 text-xs font-mono">
          <Filter className="w-3.5 h-3.5 text-cyan-400 ml-1" />
          <span className="text-slate-400">Severity Filter:</span>
          {['ALL', 'ACTION', 'MONITOR', 'NORMAL'].map((sev) => (
            <button
              key={sev}
              onClick={() => setFilterSeverity(sev)}
              className={`px-2.5 py-1 rounded-lg transition-all ${
                filterSeverity === sev
                  ? 'bg-cyan-500 text-slate-950 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {sev}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <div className="lg:col-span-8 glass-panel p-6 rounded-2xl border border-white/10 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-heading text-lg font-bold text-white">
                CABIN STRESS TIMELINE & COMFORT TREND
              </h3>
              <p className="text-xs text-slate-400 font-mono">Aggregated passenger autonomic stress vs. overall cabin comfort index</p>
            </div>
            <span className="text-xs font-mono text-cyan-400 bg-cyan-500/10 px-2.5 py-1 rounded border border-cyan-500/30">LIVE FEED</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stressTimelineData}>
                <defs>
                  <linearGradient id="colorMaxStress" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#EF4444" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#EF4444" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorComfort" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06B6D4" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#06B6D4" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="time" stroke="#64748B" fontSize={11} fontFamily="JetBrains Mono" />
                <YAxis stroke="#64748B" fontSize={11} fontFamily="JetBrains Mono" />
                <Tooltip contentStyle={{ backgroundColor: '#0B101D', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} />
                <Legend wrapperStyle={{ fontSize: '11px', fontFamily: 'JetBrains Mono' }} />
                <Area type="monotone" dataKey="maxStress" name="Max Seat Stress" stroke="#EF4444" strokeWidth={2} fillOpacity={1} fill="url(#colorMaxStress)" />
                <Area type="monotone" dataKey="comfort" name="Cabin Comfort %" stroke="#06B6D4" strokeWidth={2} fillOpacity={1} fill="url(#colorComfort)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="lg:col-span-4 glass-panel p-6 rounded-2xl border border-white/10 space-y-4">
          <h3 className="font-heading text-lg font-bold text-white">
            WELLBEING RISK DISTRIBUTION
          </h3>
          <p className="text-xs text-slate-400 font-mono">Current 36-seat status categorization</p>

          <div className="h-56 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={riskDistributionData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={80}
                  paddingAngle={4}
                  dataKey="count"
                >
                  {riskDistributionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#0B101D', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} />
                <Legend wrapperStyle={{ fontSize: '11px', fontFamily: 'JetBrains Mono' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <div className="lg:col-span-7 glass-panel p-6 rounded-2xl border border-white/10 space-y-4">
          <h3 className="font-heading text-lg font-bold text-white">
            SEAT RISK SCORE DISTRIBUTION (36 SEATS)
          </h3>
          <p className="text-xs text-slate-400 font-mono">Individual passenger composite risk score breakdown</p>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={seatRiskMapData.slice(0, 18)}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="seat" stroke="#64748B" fontSize={10} fontFamily="JetBrains Mono" />
                <YAxis domain={[0, 100]} stroke="#64748B" fontSize={11} fontFamily="JetBrains Mono" />
                <Tooltip contentStyle={{ backgroundColor: '#0B101D', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} />
                <Bar dataKey="riskScore" name="Overall Risk Score" fill="#06B6D4" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="lg:col-span-5 glass-panel p-6 rounded-2xl border border-white/10 space-y-4">
          <h3 className="font-heading text-lg font-bold text-white">
            INTERVENTION RESPONSE TIME (SEC)
          </h3>
          <p className="text-xs text-slate-400 font-mono">Average crew dispatch response time per event category</p>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={responseTimeData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis type="number" stroke="#64748B" fontSize={11} fontFamily="JetBrains Mono" />
                <YAxis dataKey="intervention" type="category" stroke="#64748B" fontSize={10} fontFamily="JetBrains Mono" width={110} />
                <Tooltip contentStyle={{ backgroundColor: '#0B101D', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} />
                <Bar dataKey="timeSec" name="Response Seconds" fill="#A855F7" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

    </div>
  );
};
