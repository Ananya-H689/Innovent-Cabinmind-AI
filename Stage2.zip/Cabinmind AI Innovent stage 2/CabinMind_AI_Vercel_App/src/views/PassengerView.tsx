import React, { useState } from 'react';
import { useCabinSimulation } from '../context/SimulationContext';
import { motion } from 'framer-motion';
import { 
  Wind, 
  Sun, 
  CheckCircle2, 
  Sparkles, 
  PlaneLanding 
} from 'lucide-react';

export const PassengerView: React.FC = () => {
  const { selectedSeat, turbulence, cabinAdaptation, postFlightReport, triggerPreset } = useCabinSimulation();
  const [activeTab, setActiveTab] = useState<'INFLIGHT' | 'POSTFLIGHT'>(postFlightReport ? 'POSTFLIGHT' : 'INFLIGHT');

  const seat = selectedSeat || {
    id: '14A',
    passengerName: 'Ananya Iyer',
    flightClass: 'Business',
    comfortScore: 88,
    wellbeing: 'CALM',
    telemetry: {
      heartRate: 72,
      hrv: 58,
      gsr: 3.4,
      temp: 36.6,
      immobilityHours: 1.8,
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-24">
      
      <div className="flex items-center justify-between glass-panel p-4 rounded-2xl border border-white/10">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300 font-mono font-bold">
            {seat.id}
          </div>
          <div>
            <h2 className="font-heading text-lg font-bold text-white">
              {seat.passengerName}'s In-Flight Suite
            </h2>
            <p className="text-xs text-slate-400 font-mono">
              CM-427 Bengaluru (BLR) → Mumbai (BOM)
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-1 bg-slate-900/80 p-1 rounded-xl border border-slate-800 text-xs font-mono">
          <button
            onClick={() => setActiveTab('INFLIGHT')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'INFLIGHT'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            IN-FLIGHT COMFORT
          </button>

          <button
            onClick={() => {
              if (!postFlightReport) triggerPreset('LANDING');
              setActiveTab('POSTFLIGHT');
            }}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center space-x-1.5 ${
              activeTab === 'POSTFLIGHT'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <PlaneLanding className="w-3.5 h-3.5" />
            <span>POST-FLIGHT RECOVERY</span>
          </button>
        </div>
      </div>

      {activeTab === 'INFLIGHT' ? (
        <div className="space-y-6">
          
          {turbulence.status !== 'CLEAR' && (
            <motion.div
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              className="glass-panel p-6 rounded-3xl border border-purple-500/40 bg-gradient-to-r from-purple-950/60 via-slate-950/80 to-purple-950/60 space-y-4 glow-purple"
            >
              <div className="flex items-center space-x-3">
                <div className="p-3 rounded-2xl bg-purple-500/20 text-purple-300 border border-purple-400/30">
                  <Wind className="w-6 h-6 animate-pulse" />
                </div>
                <div>
                  <h3 className="font-heading text-xl font-extrabold text-purple-200">
                    TURBULENCE AHEAD — PRE-CALMING IN PROGRESS
                  </h3>
                  <p className="text-xs text-slate-300">
                    CabinMind has predicted moderate air turbulence. Your cabin climate is automatically adapting for maximum comfort.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-xs pt-2">
                <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">TIME TO EVENT</span>
                  <span className="text-cyan-300 font-bold text-lg">T-{turbulence.minutesRemaining.toFixed(1)} MIN</span>
                </div>
                <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">LIGHTING MODE</span>
                  <span className="text-amber-300 font-bold">{cabinAdaptation.lighting}</span>
                </div>
                <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">CALMING AUDIO</span>
                  <span className="text-purple-300 font-bold">{cabinAdaptation.audio}</span>
                </div>
              </div>

              <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800 space-y-2 text-xs font-mono">
                <span className="text-slate-400 uppercase tracking-wider font-semibold block text-[10px]">
                  AUTOMATED PREPARATION CHECKLIST
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-300">
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Seatbelt Fastened Notification Pushed</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Warm Comfort Lighting Enabled (2700K)</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Airflow Boosted +8% Oxygen</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>432Hz Ambient Acoustic Wave Active</span>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            
            <div className="glass-panel p-6 rounded-2xl border border-cyan-500/20 text-center space-y-2">
              <span className="text-xs font-mono text-slate-400 uppercase block">YOUR COMFORT SCORE</span>
              <div className="text-4xl font-extrabold font-mono text-cyan-300">
                {seat.comfortScore} / 100
              </div>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-400/30 font-mono inline-block">
                PEAK OPTIMAL
              </span>
            </div>

            <div className="glass-panel p-6 rounded-2xl border border-white/10 text-center space-y-2">
              <span className="text-xs font-mono text-slate-400 uppercase block">STRESS & AUTONOMIC STATE</span>
              <div className="text-2xl font-bold font-mono text-emerald-400 pt-1">
                {seat.wellbeing}
              </div>
              <p className="text-[11px] text-slate-400">Heart Rate {seat.telemetry.heartRate} bpm • HRV {seat.telemetry.hrv} ms</p>
            </div>

            <div className="glass-panel p-6 rounded-2xl border border-white/10 text-center space-y-2">
              <span className="text-xs font-mono text-slate-400 uppercase block">HYDRATION & CLIMATE</span>
              <div className="text-2xl font-bold font-mono text-blue-400 pt-1">
                OPTIMAL (88%)
              </div>
              <p className="text-[11px] text-slate-400">Temp {seat.telemetry.temp.toFixed(1)}°C • Cabin Alt 8,000ft</p>
            </div>

          </div>

          <div className="glass-panel p-6 rounded-2xl border border-white/10 space-y-4">
            <h3 className="font-heading text-lg font-bold text-white flex items-center space-x-2">
              <Sun className="w-5 h-5 text-amber-400" />
              <span>PERSONALIZED SUITE CLIMATE & AMBIENCE</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
              <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 space-y-1">
                <span className="text-slate-400 block text-[10px]">LIGHTING ATMOSPHERE</span>
                <span className="text-amber-300 font-bold block">{cabinAdaptation.lighting}</span>
                <p className="text-slate-500 text-[10px]">Autonomously synced to circadian rhythm</p>
              </div>

              <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 space-y-1">
                <span className="text-slate-400 block text-[10px]">OXYGEN INFUSED AIRFLOW</span>
                <span className="text-cyan-300 font-bold block">{cabinAdaptation.airflow}</span>
                <p className="text-slate-500 text-[10px]">Maintains neural alertness & comfort</p>
              </div>

              <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 space-y-1">
                <span className="text-slate-400 block text-[10px]">ACOUSTIC THERAPY</span>
                <span className="text-purple-300 font-bold block">{cabinAdaptation.audio}</span>
                <p className="text-slate-500 text-[10px]">Suppresses 400Hz jet engine rumble</p>
              </div>
            </div>
          </div>

        </div>
      ) : (
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          <div className="glass-panel p-6 rounded-3xl border border-emerald-500/30 bg-gradient-to-r from-emerald-950/40 via-slate-950/80 to-slate-950/80 space-y-4">
            <div className="flex items-center space-x-3 border-b border-white/10 pb-4">
              <div className="p-3 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-400/30">
                <PlaneLanding className="w-6 h-6" />
              </div>
              <div>
                <h2 className="font-heading text-xl font-bold text-white">
                  YOUR CABINMIND JOURNEY SUMMARY & RECOVERY
                </h2>
                <p className="text-xs text-slate-400 font-mono">
                  Flight CM-427 Bengaluru → Mumbai • Safely Landed
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
              <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
                <span className="text-slate-400 block text-[10px]">FLIGHT COMFORT SCORE</span>
                <span className="text-2xl font-bold text-emerald-400 block">88 / 100</span>
              </div>
              <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
                <span className="text-slate-400 block text-[10px]">HYDRATION SCORE</span>
                <span className="text-2xl font-bold text-cyan-400 block">82 / 100</span>
              </div>
              <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
                <span className="text-slate-400 block text-[10px]">MOVEMENT INDEX</span>
                <span className="text-2xl font-bold text-purple-400 block">74 / 100</span>
              </div>
              <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
                <span className="text-slate-400 block text-[10px]">FATIGUE ESTIMATE</span>
                <span className="text-xs font-bold text-amber-300 block pt-1">MILD CIRCADIAN SHIFT</span>
              </div>
            </div>

            <div className="bg-slate-900/60 p-5 rounded-2xl border border-slate-800 space-y-3">
              <h3 className="font-heading text-sm font-bold text-emerald-300 flex items-center space-x-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>PERSONALIZED RECOVERY RECOMMENDATIONS</span>
              </h3>

              <div className="space-y-2 text-xs text-slate-300 font-mono">
                {(postFlightReport?.recommendations || [
                  'Drink 500ml electrolyte water upon arrival at hotel/home.',
                  'Expose eyes to natural sunlight for 20 minutes before 18:00.',
                  'Perform 10-minute hamstring and calf stretches to boost venous return.',
                  'Maintain regular sleep schedule: sleep at 22:30 local time.'
                ]).map((rec, i) => (
                  <div key={i} className="flex items-start space-x-2 p-2.5 rounded-lg bg-slate-950/60 border border-slate-800/60">
                    <span className="text-emerald-400 font-bold">{i + 1}.</span>
                    <span>{rec}</span>
                  </div>
                ))}
              </div>

              <p className="text-[10px] text-slate-500 font-mono pt-2 italic">
                * Prototype wellness suggestion based on in-flight telemetry fusion. Not a medical prescription.
              </p>
            </div>
          </div>
        </motion.div>
      )}

    </div>
  );
};
