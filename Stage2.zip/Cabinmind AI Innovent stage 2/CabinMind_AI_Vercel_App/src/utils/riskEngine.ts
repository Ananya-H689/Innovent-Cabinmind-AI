import type { TelemetryData, SeatStatus, WellbeingState } from '../types/cabin';

export interface RiskWeights {
  hrWeight: number;
  hrvWeight: number;
  gsrWeight: number;
  immobilityWeight: number;
  pressureAsymmetryWeight: number;
  tempWeight: number;
  movementWeight: number;
}

export const DEFAULT_RISK_WEIGHTS: RiskWeights = {
  hrWeight: 0.25,
  hrvWeight: 0.30,
  gsrWeight: 0.25,
  immobilityWeight: 0.35,
  pressureAsymmetryWeight: 0.20,
  tempWeight: 0.10,
  movementWeight: 0.15,
};

export interface RiskCalculationResult {
  stressScore: number;
  dvtScore: number;
  dehydrationScore: number;
  comfortScore: number;
  overallRiskScore: number;
  status: SeatStatus;
  wellbeing: WellbeingState;
  confidence: number;
  aiInsight: string;
  recommendedAction: string;
  breakdown: {
    hrFactor: number;
    hrvFactor: number;
    gsrFactor: number;
    immobilityFactor: number;
    postureFactor: number;
  };
}

/**
 * Modular Browser-Side Edge AI Risk Engine
 * Computes transparent, weighted physiological & movement feature risk scores.
 */
export function calculatePassengerRisk(
  telemetry: TelemetryData,
  weights: RiskWeights = DEFAULT_RISK_WEIGHTS
): RiskCalculationResult {
  const { heartRate, hrv, gsr, movement, seatPressure, temp, immobilityHours } = telemetry;

  // 1. Stress Score Calculation (0 - 100)
  const hrFactor = Math.min(100, Math.max(0, ((heartRate - 65) / 55) * 100));
  const hrvFactor = Math.min(100, Math.max(0, ((70 - hrv) / 55) * 100));
  const gsrFactor = Math.min(100, Math.max(0, ((gsr - 2.5) / 12) * 100));
  
  const rawStress = (hrFactor * weights.hrWeight) + (hrvFactor * weights.hrvWeight) + (gsrFactor * weights.gsrWeight);
  const stressScore = Math.round(Math.min(100, Math.max(0, rawStress / (weights.hrWeight + weights.hrvWeight + weights.gsrWeight))));

  // 2. DVT Risk Score (0 - 100)
  const immobilityFactor = Math.min(100, Math.max(0, (immobilityHours / 4.5) * 100));
  const lowMovementFactor = Math.min(100, Math.max(0, ((3.0 - movement) / 3.0) * 100));
  const pressureAsymmetry = Math.abs(seatPressure.left - seatPressure.right);
  const postureFactor = pressureAsymmetry > 15 ? 70 : 30;

  const rawDvt = (immobilityFactor * weights.immobilityWeight) + (lowMovementFactor * weights.movementWeight) + (postureFactor * weights.pressureAsymmetryWeight);
  const dvtScore = Math.round(Math.min(100, Math.max(0, rawDvt / (weights.immobilityWeight + weights.movementWeight + weights.pressureAsymmetryWeight))));

  // 3. Dehydration Risk Score (0 - 100)
  const tempFactor = Math.min(100, Math.max(0, ((temp - 36.5) / 1.8) * 100));
  const gsrMoistureDropFactor = gsr < 3.0 ? Math.min(100, ((3.0 - gsr) / 2.0) * 80) : 20;
  const dehydrationScore = Math.round(Math.min(100, Math.max(0, (tempFactor * 0.4) + (gsrMoistureDropFactor * 0.6))));

  // 4. Overall Comfort Score
  const discomfortPenalty = (stressScore * 0.4) + (dvtScore * 0.3) + (dehydrationScore * 0.3);
  const comfortScore = Math.round(Math.max(0, Math.min(100, 100 - discomfortPenalty)));

  // 5. Determine Overall Risk Score
  const maxRiskDomainScore = Math.max(stressScore, dvtScore, dehydrationScore);
  const overallRiskScore = maxRiskDomainScore;

  // 6. Classification Matrix
  let status: SeatStatus = 'NORMAL';
  if (overallRiskScore >= 76) status = 'ACTION';
  else if (overallRiskScore >= 56) status = 'MONITOR';
  else if (overallRiskScore >= 31) status = 'MILD';

  // 7. Wellbeing Labeling
  let wellbeing: WellbeingState = 'CALM';
  if (stressScore >= 78) wellbeing = 'DISTRESS';
  else if (stressScore >= 60) wellbeing = 'HIGH STRESS';
  else if (dvtScore >= 65) wellbeing = 'DVT RISK';
  else if (dehydrationScore >= 65) wellbeing = 'DEHYDRATION RISK';
  else if (stressScore >= 35) wellbeing = 'MILD ANXIETY';

  // 8. Confidence Calculation
  const signalNoise = Math.min(10, Math.abs(heartRate - 75) * 0.1);
  const confidence = Math.round(Math.max(84, Math.min(98, 96 - signalNoise)));

  // 9. AI Insight & Decision Support Wording
  let aiInsight = 'Physiological signals remain stable within calm baseline parameters.';
  let recommendedAction = 'Standard cabin service; no intervention required.';

  if (wellbeing === 'DISTRESS') {
    aiInsight = `Critical elevation in sympathetic activation: HR ${heartRate} bpm, HRV ${hrv} ms (low), GSR ${gsr} µS. Immediate anxiety peak detected.`;
    recommendedAction = 'Discreetly visit seat, offer warm towel, herbal tea, and gently check passenger wellbeing.';
  } else if (wellbeing === 'HIGH STRESS') {
    aiInsight = `Physiological indicators show elevated stress (Stress Index ${stressScore}/100) combined with suppressed heart rate variability (${hrv} ms).`;
    recommendedAction = 'Discreetly check passenger wellbeing and offer assistance or calming beverage option.';
  } else if (wellbeing === 'DVT RISK') {
    aiInsight = `Prolonged physical immobility (${immobilityHours.toFixed(1)} hrs continuous) with high static seat pressure asymmetry (${seatPressure.left}/${seatPressure.right} kPa).`;
    recommendedAction = 'Suggest cabin stroll, offer hydration, or prompt passenger with gentle seatback stretching exercise routine.';
  } else if (wellbeing === 'DEHYDRATION RISK') {
    aiInsight = `Dermal moisture signature indicates progressive fluid depletion (Dehydration Index ${dehydrationScore}/100, Temp ${temp.toFixed(1)}°C).`;
    recommendedAction = 'Offer electrolyte-infused water or fresh fruit juice during next service walkthrough.';
  } else if (wellbeing === 'MILD ANXIETY') {
    aiInsight = `Mild autonomic fluctuation detected: transient HR spike (${heartRate} bpm) during cruise phase.`;
    recommendedAction = 'Enable seatback calming ambient lighting preset and monitor on next cabin round.';
  }

  return {
    stressScore,
    dvtScore,
    dehydrationScore,
    comfortScore,
    overallRiskScore,
    status,
    wellbeing,
    confidence,
    aiInsight,
    recommendedAction,
    breakdown: {
      hrFactor: Math.round(hrFactor),
      hrvFactor: Math.round(hrvFactor),
      gsrFactor: Math.round(gsrFactor),
      immobilityFactor: Math.round(immobilityFactor),
      postureFactor: Math.round(postureFactor),
    },
  };
}
