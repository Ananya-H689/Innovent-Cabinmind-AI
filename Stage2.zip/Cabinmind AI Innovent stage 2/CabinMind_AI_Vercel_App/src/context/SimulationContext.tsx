import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { 
  SeatData, 
  AlertItem, 
  TurbulenceState, 
  CabinAdaptationState, 
  FlightInfo, 
  RoutePath 
} from '../types/cabin';
import { generateInitialSeats } from '../data/initialSeats';
import { calculatePassengerRisk } from '../utils/riskEngine';

interface SimulationContextType {
  seats: SeatData[];
  selectedSeat: SeatData | null;
  selectedSeatId: string | null;
  setSelectedSeatId: (id: string | null) => void;
  alerts: AlertItem[];
  turbulence: TurbulenceState;
  cabinAdaptation: CabinAdaptationState;
  flightInfo: FlightInfo;
  currentRoute: RoutePath;
  navigate: (path: RoutePath) => void;
  isRunning: boolean;
  speed: 1 | 3 | 8;
  simTimeStr: string;
  toggleSimulation: () => void;
  setSpeed: (s: 1 | 3 | 8) => void;
  resetSimulation: () => void;
  triggerPreset: (preset: 'STRESS' | 'DVT_RISK' | 'DEHYDRATION' | 'TURBULENCE' | 'LANDING' | 'NORMAL') => void;
  acknowledgeAlert: (id: string) => void;
  resolveAlert: (id: string) => void;
  updateCabinAdaptation: (changes: Partial<CabinAdaptationState>) => void;
  postFlightReport: {
    comfortScore: number;
    stressTrend: number[];
    hydrationScore: number;
    movementScore: number;
    fatigueEstimate: string;
    recommendations: string[];
  } | null;
}

const INITIAL_FLIGHT: FlightInfo = {
  flightNumber: 'CM-427',
  aircraft: 'Airbus A320neo (Reg: VT-CBM)',
  route: 'Bengaluru (BLR) → Mumbai (BOM)',
  origin: 'Bengaluru (BLR)',
  destination: 'Mumbai (BOM)',
  altitude: '38,000 ft',
  speed: '485 kts',
  phase: 'CRUISE',
  flightTimeElapsed: '01:24',
  flightTimeTotal: '02:15',
  cabinTemp: 22.4,
  cabinHumidity: 41,
  cabinPressure: 8000,
  aiEngineStatus: 'ACTIVE — EDGE TPU 14 TOPS',
  connectivity: 'SATCOM L-BAND (32ms)',
};

const INITIAL_ALERTS: AlertItem[] = [
  {
    id: 'ALT-101',
    timestamp: '14:23:45',
    seatId: '14A',
    passengerName: 'Ananya Iyer',
    category: 'CRITICAL',
    event: 'ACUTE SYMPATHETIC HYPER-AROUSAL',
    riskScore: 87,
    confidence: 94,
    recommendedAction: 'Discreetly offer warm towel & calming herbal beverage. Monitor HRV.',
    status: 'ACTIVE',
    assignedCrew: null,
  },
  {
    id: 'ALT-102',
    timestamp: '14:20:12',
    seatId: '16F',
    passengerName: 'Neha Gupta',
    category: 'HIGH',
    event: 'EXTENDED IMMOBILITY & DVT RISK',
    riskScore: 78,
    confidence: 92,
    recommendedAction: 'Prompt passenger with gentle seatback stretching exercise routine.',
    status: 'ACTIVE',
    assignedCrew: 'Purser Rahul',
  },
  {
    id: 'ALT-103',
    timestamp: '14:15:00',
    seatId: '13C',
    passengerName: 'Karan Johar',
    category: 'MONITOR',
    event: 'DERMAL DEHYDRATION SIGNATURE',
    riskScore: 68,
    confidence: 89,
    recommendedAction: 'Offer electrolyte hydration beverage on next cart service.',
    status: 'ACTIVE',
    assignedCrew: null,
  }
];

const SimulationContext = createContext<SimulationContextType | undefined>(undefined);

export const SimulationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [seats, setSeats] = useState<SeatData[]>(() => generateInitialSeats());
  const [selectedSeatId, setSelectedSeatId] = useState<string | null>('14A');
  const [alerts, setAlerts] = useState<AlertItem[]>(INITIAL_ALERTS);
  const [flightInfo] = useState<FlightInfo>(INITIAL_FLIGHT);

  const [currentRoute, setCurrentRoute] = useState<RoutePath>(() => {
    const hash = window.location.hash.replace('#', '');
    if (['/crew', '/passenger', '/analytics', '/hardware', '/engine'].includes(hash)) {
      return hash as RoutePath;
    }
    const path = window.location.pathname;
    if (['/crew', '/passenger', '/analytics', '/hardware', '/engine'].includes(path)) {
      return path as RoutePath;
    }
    return '/';
  });

  const navigate = useCallback((path: RoutePath) => {
    setCurrentRoute(path);
    window.location.hash = path;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '');
      if (['/', '/crew', '/passenger', '/analytics', '/hardware', '/engine'].includes(hash)) {
        setCurrentRoute(hash as RoutePath);
      }
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const [turbulence, setTurbulence] = useState<TurbulenceState>({
    status: 'CLEAR',
    minutesRemaining: 12,
    intensity: 'Moderate',
    confidence: 91,
    activeStage: 'NORMAL',
    stageMessage: 'Clear air condition. Flight path optimal.',
  });

  const [cabinAdaptation, setCabinAdaptation] = useState<CabinAdaptationState>({
    lighting: 'Warm Comfort Mode (2700K)',
    airflow: '+8% Oxygen Balance',
    audio: 'Ambient Calming 432Hz',
    seatbeltAlert: false,
    crewReadiness: 'STANDARD',
  });

  const [isRunning, setIsRunning] = useState<boolean>(true);
  const [speed, setSpeed] = useState<1 | 3 | 8>(1);
  const [simSeconds, setSimSeconds] = useState<number>(5040);

  const [postFlightReport, setPostFlightReport] = useState<SimulationContextType['postFlightReport']>(null);

  const toggleSimulation = () => setIsRunning(prev => !prev);

  const updateCabinAdaptation = (changes: Partial<CabinAdaptationState>) => {
    setCabinAdaptation(prev => ({ ...prev, ...changes }));
  };

  const acknowledgeAlert = (id: string) => {
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, status: 'ACKNOWLEDGED' } : a));
  };

  const resolveAlert = (id: string) => {
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, status: 'RESOLVED' } : a));
  };

  const resetSimulation = () => {
    setSeats(generateInitialSeats());
    setSelectedSeatId('14A');
    setAlerts(INITIAL_ALERTS);
    setTurbulence({
      status: 'CLEAR',
      minutesRemaining: 12,
      intensity: 'Moderate',
      confidence: 91,
      activeStage: 'NORMAL',
      stageMessage: 'Clear air condition. Flight path optimal.',
    });
    setCabinAdaptation({
      lighting: 'Warm Comfort Mode (2700K)',
      airflow: '+8% Oxygen Balance',
      audio: 'Ambient Calming 432Hz',
      seatbeltAlert: false,
      crewReadiness: 'STANDARD',
    });
    setSimSeconds(5040);
    setPostFlightReport(null);
  };

  const triggerPreset = (preset: 'STRESS' | 'DVT_RISK' | 'DEHYDRATION' | 'TURBULENCE' | 'LANDING' | 'NORMAL') => {
    if (preset === 'STRESS') {
      setSelectedSeatId('14A');
      setSeats(prev => prev.map(s => {
        if (s.id !== '14A') return s;
        const newTelemetry = {
          ...s.telemetry,
          heartRate: 118,
          hrv: 18,
          gsr: 16.4,
          movement: 0.8,
          posture: 'Rigid' as const,
          hrHistory: [...s.telemetry.hrHistory.slice(1), 118],
          hrvHistory: [...s.telemetry.hrvHistory.slice(1), 18],
          gsrHistory: [...s.telemetry.gsrHistory.slice(1), 16.4],
        };
        const calc = calculatePassengerRisk(newTelemetry);
        return {
          ...s,
          telemetry: newTelemetry,
          status: calc.status,
          wellbeing: calc.wellbeing,
          riskScore: calc.overallRiskScore,
          stressScore: calc.stressScore,
          aiInsight: calc.aiInsight,
          recommendedAction: calc.recommendedAction,
        };
      }));

      const newAlert: AlertItem = {
        id: `ALT-${Date.now().toString().slice(-4)}`,
        timestamp: new Date().toLocaleTimeString('en-US', { hour12: false }),
        seatId: '14A',
        passengerName: 'Ananya Iyer',
        category: 'CRITICAL',
        event: 'ACUTE ANXIETY & HYPER-AROUSAL DETECTED',
        riskScore: 92,
        confidence: 96,
        recommendedAction: 'Discreetly offer warm towel & calming herbal tea. Assist passenger.',
        status: 'ACTIVE',
        assignedCrew: null,
      };
      setAlerts(prev => [newAlert, ...prev]);

    } else if (preset === 'DVT_RISK') {
      setSelectedSeatId('16F');
      setSeats(prev => prev.map(s => {
        if (s.id !== '16F') return s;
        const newTelemetry = {
          ...s.telemetry,
          immobilityHours: 4.8,
          movement: 0.1,
          seatPressure: { left: 74, right: 22, back: 55 },
          posture: 'Slouched' as const,
        };
        const calc = calculatePassengerRisk(newTelemetry);
        return {
          ...s,
          telemetry: newTelemetry,
          status: calc.status,
          wellbeing: calc.wellbeing,
          riskScore: calc.overallRiskScore,
          dvtScore: calc.dvtScore,
          aiInsight: calc.aiInsight,
          recommendedAction: calc.recommendedAction,
        };
      }));

      const newAlert: AlertItem = {
        id: `ALT-${Date.now().toString().slice(-4)}`,
        timestamp: new Date().toLocaleTimeString('en-US', { hour12: false }),
        seatId: '16F',
        passengerName: 'Neha Gupta',
        category: 'HIGH',
        event: 'HIGH DVT RISK — PROLONGED IMMOBILITY (4.8h)',
        riskScore: 84,
        confidence: 93,
        recommendedAction: 'Advise passenger stretching routine or offer hydration stroll.',
        status: 'ACTIVE',
        assignedCrew: null,
      };
      setAlerts(prev => [newAlert, ...prev]);

    } else if (preset === 'DEHYDRATION') {
      setSelectedSeatId('13C');
      setSeats(prev => prev.map(s => {
        if (s.id !== '13C') return s;
        const newTelemetry = {
          ...s.telemetry,
          temp: 37.9,
          gsr: 1.4,
          heartRate: 88,
        };
        const calc = calculatePassengerRisk(newTelemetry);
        return {
          ...s,
          telemetry: newTelemetry,
          status: calc.status,
          wellbeing: calc.wellbeing,
          riskScore: calc.overallRiskScore,
          dehydrationScore: calc.dehydrationScore,
          aiInsight: calc.aiInsight,
          recommendedAction: calc.recommendedAction,
        };
      }));

      const newAlert: AlertItem = {
        id: `ALT-${Date.now().toString().slice(-4)}`,
        timestamp: new Date().toLocaleTimeString('en-US', { hour12: false }),
        seatId: '13C',
        passengerName: 'Karan Johar',
        category: 'MONITOR',
        event: 'ELEVATED DEHYDRATION INDEX (76/100)',
        riskScore: 76,
        confidence: 91,
        recommendedAction: 'Serve fresh electrolyte water beverage to seat 13C.',
        status: 'ACTIVE',
        assignedCrew: null,
      };
      setAlerts(prev => [newAlert, ...prev]);

    } else if (preset === 'TURBULENCE') {
      setTurbulence({
        status: 'PREDICTED',
        minutesRemaining: 12,
        intensity: 'Severe',
        confidence: 94,
        activeStage: 'T-12',
        stageMessage: 'T-12m: AI Doppler Radar & Telemetry predicts severe convective turbulence ahead.',
      });

      const newAlert: AlertItem = {
        id: `ALT-TURB-${Date.now().toString().slice(-3)}`,
        timestamp: new Date().toLocaleTimeString('en-US', { hour12: false }),
        seatId: 'CABIN',
        passengerName: 'All Passengers',
        category: 'CRITICAL',
        event: 'PREDICTIVE TURBULENCE ALERT (T-12 MIN)',
        riskScore: 94,
        confidence: 94,
        recommendedAction: 'Initiate T-12 Cabin Pre-Calming & Seatbelt Preparation protocol.',
        status: 'ACTIVE',
        assignedCrew: 'Lead Purser',
      };
      setAlerts(prev => [newAlert, ...prev]);

    } else if (preset === 'LANDING') {
      setPostFlightReport({
        comfortScore: 88,
        stressTrend: [35, 42, 68, 74, 52, 38, 28, 22],
        hydrationScore: 82,
        movementScore: 74,
        fatigueEstimate: 'MILD JETLAG / 1.4h CIRCADIAN SHIFT',
        recommendations: [
          'Drink 500ml electrolyte water upon arrival at hotel/home.',
          'Expose eyes to natural sunlight for 20 minutes before 18:00.',
          'Perform 10-minute hamstring and calf stretches to boost venous return.',
          'Maintain regular sleep schedule: sleep at 22:30 local time.'
        ],
      });
      navigate('/passenger');
    }
  };

  useEffect(() => {
    if (!isRunning) return;

    const interval = setInterval(() => {
      setSimSeconds(prev => prev + (1 * speed));

      setSeats(prevSeats => {
        return prevSeats.map(seat => {
          const hrDelta = (Math.random() - 0.49) * 2;
          const hrvDelta = (Math.random() - 0.49) * 2;
          const gsrDelta = (Math.random() - 0.49) * 0.1;

          const newHR = Math.round(Math.max(52, Math.min(135, seat.telemetry.heartRate + hrDelta)));
          const newHRV = Math.round(Math.max(12, Math.min(95, seat.telemetry.hrv + hrvDelta)));
          const newGSR = parseFloat(Math.max(1.0, Math.min(22.0, seat.telemetry.gsr + gsrDelta)).toFixed(1));

          const newHRHistory = [...seat.telemetry.hrHistory.slice(1), newHR];
          const newHRVHistory = [...seat.telemetry.hrvHistory.slice(1), newHRV];
          const newGSRHistory = [...seat.telemetry.gsrHistory.slice(1), newGSR];

          const updatedTelemetry = {
            ...seat.telemetry,
            heartRate: newHR,
            hrv: newHRV,
            gsr: newGSR,
            hrHistory: newHRHistory,
            hrvHistory: newHRVHistory,
            gsrHistory: newGSRHistory,
          };

          const riskCalc = calculatePassengerRisk(updatedTelemetry);

          return {
            ...seat,
            telemetry: updatedTelemetry,
            status: riskCalc.status,
            wellbeing: riskCalc.wellbeing,
            riskScore: riskCalc.overallRiskScore,
            stressScore: riskCalc.stressScore,
            dvtScore: riskCalc.dvtScore,
            dehydrationScore: riskCalc.dehydrationScore,
            comfortScore: riskCalc.comfortScore,
            confidence: riskCalc.confidence,
            aiInsight: riskCalc.aiInsight,
            recommendedAction: riskCalc.recommendedAction,
            lastUpdated: new Date().toLocaleTimeString('en-US', { hour12: false }),
          };
        });
      });

      setTurbulence(prevTurb => {
        if (prevTurb.status === 'CLEAR') return prevTurb;

        const nextMins = Math.max(0, prevTurb.minutesRemaining - (0.05 * speed));

        let stage: TurbulenceState['activeStage'] = prevTurb.activeStage;
        let status: TurbulenceState['status'] = prevTurb.status;
        let msg = prevTurb.stageMessage;

        if (nextMins <= 0) {
          stage = 'T-0';
          status = 'ACTIVE_TURBULENCE';
          msg = 'T-0m: TURBULENCE EVENT ACTIVE. Cabin adaptation complete. All passengers seated safely.';
        } else if (nextMins <= 4) {
          stage = 'T-4';
          status = 'ADAPTING';
          msg = 'T-4m: Cabin Adaptation Active — Warm soothing lighting, +8% airflow, ambient audio online.';
          setCabinAdaptation({
            lighting: 'Pre-Turbulence Soft Amber (2400K)',
            airflow: '+12% Cool Circulation',
            audio: 'Ambient Calming 432Hz Binaural',
            seatbeltAlert: true,
            crewReadiness: 'IMMINENT',
          });
        } else if (nextMins <= 8) {
          stage = 'T-8';
          status = 'PREPARING';
          msg = 'T-8m: Passenger Preparation — Discreet notifications pushed to seatback screens.';
        }

        return {
          ...prevTurb,
          minutesRemaining: parseFloat(nextMins.toFixed(1)),
          activeStage: stage,
          status,
          stageMessage: msg,
        };
      });

    }, 1000);

    return () => clearInterval(interval);
  }, [isRunning, speed]);

  const selectedSeat = seats.find(s => s.id === selectedSeatId) || seats[0] || null;

  const hours = Math.floor(simSeconds / 3600);
  const mins = Math.floor((simSeconds % 3600) / 60);
  const secs = Math.floor(simSeconds % 60);
  const simTimeStr = `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')} UTC`;

  return (
    <SimulationContext.Provider
      value={{
        seats,
        selectedSeat,
        selectedSeatId,
        setSelectedSeatId,
        alerts,
        turbulence,
        cabinAdaptation,
        flightInfo,
        currentRoute,
        navigate,
        isRunning,
        speed,
        simTimeStr,
        toggleSimulation,
        setSpeed,
        resetSimulation,
        triggerPreset,
        acknowledgeAlert,
        resolveAlert,
        updateCabinAdaptation,
        postFlightReport,
      }}
    >
      {children}
    </SimulationContext.Provider>
  );
};

export const useCabinSimulation = () => {
  const context = useContext(SimulationContext);
  if (!context) {
    throw new Error('useCabinSimulation must be used within a SimulationProvider');
  }
  return context;
};
