import type { SeatData } from '../types/cabin';
import { calculatePassengerRisk } from '../utils/riskEngine';

const PASSENGER_NAMES = [
  'Aarav Sharma', 'Priya Patel', 'Vikram Malhotra', 'Ananya Iyer', 'Rahul Verma', 'Sneha Kapoor',
  'David Miller', 'Elena Rostova', 'Rohan Sen', 'Meera Rao', 'Karan Johar', 'Neha Gupta',
  'Arjun Mehta', 'Kavya Singh', 'Siddharth Roy', 'Pooja Reddy', 'Tanya Bhatia', 'Aditya Joshi',
  'Varun Nair', 'Riya Chawla', 'Kabir Khan', 'Simran Gill', 'Ishaan Agarwal', 'Divya Saxena',
  'Yash Chopra', 'Nisha Bajaj', 'Manish Pandey', 'Shruti Hassan', 'Abhinav Kumar', 'Swati Deshmukh',
  'Kiran Bedi', 'Deepak Hooda', 'Sunita Williams', 'Rajesh Khanna', 'Geeta Phogat', 'Amitabh Sen'
];

export function generateInitialSeats(): SeatData[] {
  const seats: SeatData[] = [];
  const rows = [12, 13, 14, 15, 16, 17]; // 6 rows
  const letters: ('A' | 'B' | 'C' | 'D' | 'E' | 'F')[] = ['A', 'B', 'C', 'D', 'E', 'F'];
  
  let index = 0;

  for (const r of rows) {
    for (const l of letters) {
      const id = `${r}${l}`;
      const passengerName = PASSENGER_NAMES[index % PASSENGER_NAMES.length];
      const age = 24 + ((index * 7) % 45);
      const gender = index % 2 === 0 ? 'M' : 'F';
      const flightClass = r <= 13 ? 'Business' : 'Economy';

      let hr = 68 + (index % 8);
      let hrv = 62 - (index % 10);
      let gsr = 3.2 + (index % 5) * 0.2;
      let movement = 2.5 + (index % 4) * 0.5;
      let leftP = 42 + (index % 5);
      let rightP = 44 - (index % 5);
      let backP = 50;
      let temp = 36.6 + (index % 3) * 0.1;
      let immobility = 1.2 + (index % 3) * 0.4;
      let posture: 'Balanced' | 'Slouched' | 'Restless' | 'Rigid' = 'Balanced';

      if (id === '14A') {
        hr = 108;
        hrv = 24;
        gsr = 14.8;
        movement = 1.1;
        posture = 'Rigid';
        temp = 37.1;
        immobility = 2.4;
      } else if (id === '16F') {
        hr = 74;
        hrv = 45;
        gsr = 3.8;
        movement = 0.2;
        immobility = 4.3;
        leftP = 68;
        rightP = 28;
        posture = 'Slouched';
      } else if (id === '13C') {
        hr = 84;
        hrv = 42;
        gsr = 1.9;
        movement = 1.8;
        temp = 37.7;
        immobility = 2.8;
        posture = 'Restless';
      } else if (id === '15B') {
        hr = 89;
        hrv = 38;
        gsr = 7.4;
        movement = 4.2;
        posture = 'Restless';
      }

      const hrHistory = Array.from({ length: 10 }, (_, i) => Math.round(hr + Math.sin(i) * 3));
      const hrvHistory = Array.from({ length: 10 }, (_, i) => Math.round(hrv + Math.cos(i) * 4));
      const gsrHistory = Array.from({ length: 10 }, (_, i) => parseFloat((gsr + Math.sin(i) * 0.3).toFixed(1)));

      const telemetry = {
        heartRate: hr,
        hrv,
        gsr,
        movement,
        seatPressure: { left: leftP, right: rightP, back: backP },
        posture,
        temp,
        immobilityHours: immobility,
        hrHistory,
        hrvHistory,
        gsrHistory,
      };

      const riskCalc = calculatePassengerRisk(telemetry);

      seats.push({
        id,
        row: r,
        letter: l,
        passengerName,
        age,
        gender,
        flightClass,
        status: riskCalc.status,
        wellbeing: riskCalc.wellbeing,
        riskScore: riskCalc.overallRiskScore,
        confidence: riskCalc.confidence,
        dvtScore: riskCalc.dvtScore,
        dehydrationScore: riskCalc.dehydrationScore,
        stressScore: riskCalc.stressScore,
        comfortScore: riskCalc.comfortScore,
        telemetry,
        aiInsight: riskCalc.aiInsight,
        recommendedAction: riskCalc.recommendedAction,
        lastUpdated: '14:24:02 UTC',
      });

      index++;
    }
  }

  return seats;
}
