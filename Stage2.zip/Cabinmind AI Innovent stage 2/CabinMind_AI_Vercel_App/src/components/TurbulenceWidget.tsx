import React from 'react';
import { useCabinSimulation } from '../context/SimulationContext';
import { motion } from 'framer-motion';
import { 
  Wind, 
  Clock, 
  Radio, 
  CheckCircle2, 
  Sparkles 
} from 'lucide-react';

export const TurbulenceWidget: React.FC = () => {
  const { turbulence, triggerPreset } = useCabinSimulation();

  const stages = [
    {
      id: 'T-12',
      title: 'T-12m: AI Radar Prediction',
      desc: 'Doppler satellite & IMU fusion predicts convective turbulence. Crew dispatched.',
      active: turbulence.minutesRemaining <= 12 && turbulence.minutesRemaining > 8,
      passed: turbulence.minutesRemaining <= 8,
    },
    {
      id: 'T-8',
      title: 'T-8m: Passenger Preparation',
      desc: 'Reassuring notifications sent to seatbacks. Hydration offered.',
      active: turbulence.minutesRemaining <= 8 && turbulence.minutesRemaining > 4,
      passed: turbulence.minutesRemaining <= 4,
    },
    {
      id: 'T-4',
      title: 'T-4m: Cabin Environment Adaptation',
      desc: 'Warm soothing lighting engaged. Airflow +8% oxygen. 432Hz audio active.',
      active: turbulence.minutesRemaining <= 4 && turbulence.minutesRemaining > 0,
      passed: turbulence.minutesRemaining <= 0,
    },
    {
      id: 'T-0',
      title: 'T-0m: Turbulence Event Active',
      desc: 'Aircraft traversing turbulence. Passengers calm and safely buckled.',
      active: turbulence.minutesRemaining <= 0,
      passed: false,
    },
  ];

  return (
    <div className="glass-panel rounded-2xl p-6 border border-white/10 space-y-6 relative overflow-hidden">
      
      <div className={`absolute top-0 right-0 w-80 h-80 rounded-full blur-3xl pointer-events-none transition-all ${
        turbulence.status === 'ACTIVE_TURBULENCE' ? 'bg-purple-600/20' : turbulence.status !== 'CLEAR' ? 'bg-amber-500/15' : 'bg-cyan-500/10'
      }`} />

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4 relative z-10">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-purple-500/20 border border-purple-400/30 text-purple-300 shadow-lg shadow-purple-500/10">
            <Wind className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="font-heading text-lg font-bold text-white tracking-wide">
                PREDICTIVE TURBULENCE INTELLIGENCE
              </h3>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-purple-500/20 text-purple-300 border border-purple-400/30">
                12-MIN ADVANCE WINDOW
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Micro-meteorological radar fusion vs. conventional 30-second warning
            </p>
          </div>
        </div>

        <button
          onClick={() => triggerPreset('TURBULENCE')}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-mono text-xs font-bold hover:from-purple-500 hover:to-indigo-500 shadow-lg shadow-purple-900/30 transition-all flex items-center space-x-2 self-start sm:self-auto"
        >
          <Sparkles className="w-4 h-4 text-purple-200" />
          <span>SIMULATE T-12 TURBULENCE</span>
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 relative z-10">
        
        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">CURRENT ATMOSPHERIC STATE</span>
          <span className={`text-base font-bold font-mono mt-1 block ${turbulence.status === 'CLEAR' ? 'text-emerald-400' : 'text-purple-300'}`}>
            {turbulence.status === 'CLEAR' ? 'CLEAR AIR' : turbulence.status}
          </span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">AI PREDICTION & INTENSITY</span>
          <div className="flex items-baseline space-x-2 mt-1 font-mono">
            <span className="text-base font-bold text-amber-300">{turbulence.intensity.toUpperCase()} TURBULENCE</span>
            <span className="text-xs text-slate-400">({turbulence.confidence}% Conf)</span>
          </div>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">TIMELINE COUNTDOWN</span>
          <div className="flex items-baseline space-x-1.5 mt-1 font-mono">
            <Clock className="w-4 h-4 text-cyan-400 inline" />
            <span className="text-xl font-bold text-cyan-300">
              T-{turbulence.minutesRemaining.toFixed(1)}m
            </span>
          </div>
        </div>

      </div>

      <div className="space-y-4 pt-2 relative z-10">
        <h4 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider">
          Pre-Calming & Adaptation Sequence Timeline
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          {stages.map((stg) => (
            <motion.div
              key={stg.id}
              animate={{ scale: stg.active ? 1.02 : 1 }}
              className={`p-4 rounded-xl border transition-all relative ${
                stg.active
                  ? 'bg-purple-950/40 border-purple-400/60 shadow-lg shadow-purple-500/20 ring-1 ring-purple-400'
                  : stg.passed
                  ? 'bg-slate-900/60 border-emerald-500/40 opacity-80'
                  : 'bg-slate-900/40 border-slate-800 opacity-60'
              }`}
            >
              <div className="flex items-center justify-between mb-2 font-mono">
                <span className={`text-xs font-bold ${stg.active ? 'text-purple-300' : stg.passed ? 'text-emerald-400' : 'text-slate-400'}`}>
                  {stg.id}
                </span>
                {stg.passed ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                ) : stg.active ? (
                  <Radio className="w-4 h-4 text-purple-400 animate-ping" />
                ) : (
                  <Clock className="w-4 h-4 text-slate-600" />
                )}
              </div>

              <h5 className="text-xs font-bold text-white mb-1">
                {stg.title}
              </h5>

              <p className="text-[11px] text-slate-400 leading-relaxed">
                {stg.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>

    </div>
  );
};
