import React from 'react';
import { useCabinSimulation } from '../context/SimulationContext';
import { ResponsiveContainer, AreaChart, Area, YAxis } from 'recharts';
import { 
  Heart, 
  Activity, 
  Zap, 
  Sparkles, 
  CheckCircle2, 
  Clock 
} from 'lucide-react';

export const PassengerDetailPanel: React.FC = () => {
  const { selectedSeat } = useCabinSimulation();

  if (!selectedSeat) {
    return (
      <div className="glass-panel p-8 rounded-2xl text-center text-slate-400">
        Select a seat on the cabin map to view live passenger telemetry & AI recommendations.
      </div>
    );
  }

  const {
    id,
    passengerName,
    age,
    gender,
    flightClass,
    status,
    wellbeing,
    riskScore,
    confidence,
    telemetry,
    aiInsight,
    recommendedAction,
    lastUpdated
  } = selectedSeat;

  const hrChartData = telemetry.hrHistory.map((val, idx) => ({ t: idx, hr: val }));
  const hrvChartData = telemetry.hrvHistory.map((val, idx) => ({ t: idx, hrv: val }));
  const gsrChartData = telemetry.gsrHistory.map((val, idx) => ({ t: idx, gsr: val }));

  const getWellbeingBadgeClass = (wb: string) => {
    switch (wb) {
      case 'DISTRESS':
      case 'HIGH STRESS':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/40 glow-red';
      case 'DVT RISK':
      case 'DEHYDRATION RISK':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40 glow-amber';
      case 'MILD ANXIETY':
      case 'TURBULENCE DISCOMFORT':
        return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/40';
      case 'CALM':
      default:
        return 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 glow-cyan';
    }
  };

  return (
    <div className="glass-panel rounded-2xl p-6 border border-white/10 space-y-6 relative overflow-hidden">
      
      <div className={`absolute top-0 right-0 w-64 h-64 rounded-full blur-3xl pointer-events-none ${
        status === 'ACTION' ? 'bg-rose-500/10' : status === 'MONITOR' ? 'bg-amber-500/10' : 'bg-cyan-500/10'
      }`} />

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4 relative z-10">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-600/20 border border-cyan-400/30 flex items-center justify-center text-cyan-300 font-mono font-bold text-lg shadow-lg">
            {id}
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="font-heading text-xl font-bold text-white tracking-wide">
                {passengerName}
              </h2>
              <span className="text-xs px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300 font-mono">
                {flightClass} • {age}y {gender}
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono flex items-center space-x-2 mt-0.5">
              <Clock className="w-3 h-3 text-cyan-400 inline" />
              <span>Telemetry sync: {lastUpdated}</span>
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <div className={`px-3 py-1.5 rounded-xl border text-xs font-mono font-bold tracking-wider ${getWellbeingBadgeClass(wellbeing)}`}>
            {wellbeing}
          </div>
          <div className="bg-slate-900/90 border border-slate-800 px-3 py-1.5 rounded-xl text-right font-mono text-xs">
            <span className="text-slate-400 block text-[10px]">AI CONFIDENCE</span>
            <span className="text-cyan-300 font-bold">{confidence}%</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 relative z-10">
        
        <div className="bg-slate-900/70 p-3.5 rounded-xl border border-slate-800">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">Risk Score</span>
          <div className="flex items-baseline space-x-1 mt-1">
            <span className={`text-2xl font-bold font-mono ${riskScore > 75 ? 'text-rose-400' : riskScore > 50 ? 'text-amber-400' : 'text-cyan-400'}`}>
              {riskScore}
            </span>
            <span className="text-xs text-slate-500 font-mono">/ 100</span>
          </div>
        </div>

        <div className="bg-slate-900/70 p-3.5 rounded-xl border border-slate-800">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">Heart Rate</span>
          <div className="flex items-baseline space-x-1 mt-1">
            <span className="text-2xl font-bold font-mono text-emerald-400">{telemetry.heartRate}</span>
            <span className="text-xs text-slate-400 font-mono">bpm</span>
          </div>
        </div>

        <div className="bg-slate-900/70 p-3.5 rounded-xl border border-slate-800">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">HRV</span>
          <div className="flex items-baseline space-x-1 mt-1">
            <span className="text-2xl font-bold font-mono text-cyan-400">{telemetry.hrv}</span>
            <span className="text-xs text-slate-400 font-mono">ms</span>
          </div>
        </div>

        <div className="bg-slate-900/70 p-3.5 rounded-xl border border-slate-800">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">GSR Conductance</span>
          <div className="flex items-baseline space-x-1 mt-1">
            <span className="text-2xl font-bold font-mono text-purple-400">{telemetry.gsr}</span>
            <span className="text-xs text-slate-400 font-mono">µS</span>
          </div>
        </div>

      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 relative z-10">
        
        <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800/80 space-y-2">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-slate-300 font-semibold flex items-center space-x-1">
              <Heart className="w-3.5 h-3.5 text-rose-500 animate-pulse" />
              <span>Heart Rate Stream</span>
            </span>
            <span className="text-emerald-400 font-bold">{telemetry.heartRate} BPM</span>
          </div>
          <div className="h-20 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={hrChartData}>
                <defs>
                  <linearGradient id="colorHr" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#EF4444" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#EF4444" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <YAxis domain={['dataMin - 5', 'dataMax + 5']} hide />
                <Area type="monotone" dataKey="hr" stroke="#EF4444" strokeWidth={2} fillOpacity={1} fill="url(#colorHr)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800/80 space-y-2">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-slate-300 font-semibold flex items-center space-x-1">
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              <span>HRV Autonomic Signature</span>
            </span>
            <span className="text-cyan-400 font-bold">{telemetry.hrv} MS</span>
          </div>
          <div className="h-20 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={hrvChartData}>
                <defs>
                  <linearGradient id="colorHrv" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06B6D4" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#06B6D4" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <YAxis domain={['dataMin - 5', 'dataMax + 5']} hide />
                <Area type="monotone" dataKey="hrv" stroke="#06B6D4" strokeWidth={2} fillOpacity={1} fill="url(#colorHrv)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800/80 space-y-2">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-slate-300 font-semibold flex items-center space-x-1">
              <Zap className="w-3.5 h-3.5 text-purple-400" />
              <span>GSR Electrodermal Arousal</span>
            </span>
            <span className="text-purple-400 font-bold">{telemetry.gsr} µS</span>
          </div>
          <div className="h-20 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={gsrChartData}>
                <defs>
                  <linearGradient id="colorGsr" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#A855F7" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#A855F7" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <YAxis domain={['dataMin - 0.5', 'dataMax + 0.5']} hide />
                <Area type="monotone" dataKey="gsr" stroke="#A855F7" strokeWidth={2} fillOpacity={1} fill="url(#colorGsr)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-900/40 p-4 rounded-xl border border-slate-800/60 text-xs font-mono relative z-10">
        <div>
          <span className="text-slate-400 block text-[10px]">BODY TEMP</span>
          <span className="text-slate-200 font-bold">{telemetry.temp.toFixed(1)} °C</span>
        </div>
        <div>
          <span className="text-slate-400 block text-[10px]">IMMOBILITY DURATION</span>
          <span className="text-amber-300 font-bold">{telemetry.immobilityHours.toFixed(1)} hrs</span>
        </div>
        <div>
          <span className="text-slate-400 block text-[10px]">POSTURE MATRIX</span>
          <span className="text-cyan-300 font-bold">{telemetry.posture}</span>
        </div>
        <div>
          <span className="text-slate-400 block text-[10px]">SEAT PRESSURE L/R</span>
          <span className="text-slate-200 font-bold">{telemetry.seatPressure.left} / {telemetry.seatPressure.right} kPa</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 relative z-10">
        
        <div className="bg-cyan-950/20 border border-cyan-500/30 p-4 rounded-xl space-y-2">
          <div className="flex items-center space-x-2 text-cyan-300 text-xs font-mono font-bold">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span>AI EDGE ENGINE REASONING</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            "{aiInsight}"
          </p>
        </div>

        <div className="bg-emerald-950/20 border border-emerald-500/30 p-4 rounded-xl space-y-2">
          <div className="flex items-center space-x-2 text-emerald-300 text-xs font-mono font-bold">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>DECISION SUPPORT RECOMMENDED ACTION</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed font-medium">
            "{recommendedAction}"
          </p>
          <p className="text-[10px] text-slate-500 font-mono pt-1 italic">
            * Operational decision support tool. Does not constitute a clinical medical diagnosis.
          </p>
        </div>

      </div>

    </div>
  );
};
