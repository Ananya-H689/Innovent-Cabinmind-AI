import React, { useState } from 'react';
import { useCabinSimulation } from '../context/SimulationContext';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Zap, 
  AlertTriangle, 
  Activity, 
  Droplets, 
  Wind, 
  PlaneLanding, 
  ChevronUp, 
  ChevronDown 
} from 'lucide-react';

export const DemoControlCenter: React.FC = () => {
  const { 
    isRunning, 
    toggleSimulation, 
    speed, 
    setSpeed, 
    resetSimulation, 
    triggerPreset, 
    simTimeStr 
  } = useCabinSimulation();

  const [isExpanded, setIsExpanded] = useState<boolean>(true);

  return (
    <div className="fixed bottom-4 left-1/2 transform -translate-x-1/2 z-50 w-full max-w-4xl px-4">
      <div className="glass-panel border border-cyan-500/30 rounded-2xl shadow-2xl shadow-cyan-950/40 bg-[#0B101D]/90 backdrop-blur-2xl overflow-hidden transition-all duration-300">
        
        <div className="flex items-center justify-between px-5 py-3 border-b border-white/10 bg-white/5">
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-1.5 bg-cyan-500/20 text-cyan-300 px-2.5 py-1 rounded-md text-xs font-mono font-semibold border border-cyan-400/30">
              <Zap className="w-3.5 h-3.5 text-cyan-400" />
              <span>DEMO CONTROL CENTER</span>
            </div>
            <span className="text-xs text-slate-400 font-mono hidden sm:inline">
              InnoVent-27 Live Presentation Controls
            </span>
          </div>

          <div className="flex items-center space-x-4">
            <div className="text-xs font-mono text-cyan-400 font-bold hidden md:block">
              {simTimeStr}
            </div>

            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
            >
              {isExpanded ? <ChevronDown className="w-5 h-5" /> : <ChevronUp className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {isExpanded && (
          <div className="p-4 space-y-4">
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              
              <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800 space-y-2">
                <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider font-semibold">
                  Execution State & Speed
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={toggleSimulation}
                    className={`flex-1 flex items-center justify-center space-x-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
                      isRunning 
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
                        : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
                    }`}
                  >
                    {isRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                    <span>{isRunning ? 'PAUSE' : 'START FLIGHT'}</span>
                  </button>

                  <button
                    onClick={resetSimulation}
                    className="p-2 rounded-lg bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700 hover:text-white transition-colors"
                    title="Reset All Simulated Data"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="flex items-center space-x-1 pt-1">
                  <span className="text-[10px] text-slate-400 font-mono mr-1">Speed:</span>
                  {([1, 3, 8] as const).map((s) => (
                    <button
                      key={s}
                      onClick={() => setSpeed(s)}
                      className={`flex-1 py-1 rounded text-[11px] font-mono font-bold transition-all ${
                        speed === s
                          ? 'bg-cyan-500 text-slate-950 shadow-sm shadow-cyan-500/40'
                          : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-slate-200'
                      }`}
                    >
                      {s}x
                    </button>
                  ))}
                </div>
              </div>

              <div className="md:col-span-2 bg-slate-900/60 p-3 rounded-xl border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider font-semibold">
                    Simulate Live In-Flight Events
                  </span>
                  <span className="text-[10px] text-cyan-400 font-mono">Instant AI Trigger</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  
                  <button
                    onClick={() => triggerPreset('STRESS')}
                    className="flex flex-col items-center justify-center p-2 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 hover:bg-rose-500/20 hover:border-rose-500/50 transition-all text-center group"
                  >
                    <Activity className="w-4 h-4 text-rose-400 mb-1 group-hover:scale-110 transition-transform" />
                    <span className="text-[10px] font-mono font-bold">STRESS</span>
                    <span className="text-[9px] text-slate-400">Seat 14A</span>
                  </button>

                  <button
                    onClick={() => triggerPreset('DVT_RISK')}
                    className="flex flex-col items-center justify-center p-2 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-300 hover:bg-amber-500/20 hover:border-amber-500/50 transition-all text-center group"
                  >
                    <AlertTriangle className="w-4 h-4 text-amber-400 mb-1 group-hover:scale-110 transition-transform" />
                    <span className="text-[10px] font-mono font-bold">DVT RISK</span>
                    <span className="text-[9px] text-slate-400">Seat 16F</span>
                  </button>

                  <button
                    onClick={() => triggerPreset('DEHYDRATION')}
                    className="flex flex-col items-center justify-center p-2 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 hover:bg-cyan-500/20 hover:border-cyan-500/50 transition-all text-center group"
                  >
                    <Droplets className="w-4 h-4 text-cyan-400 mb-1 group-hover:scale-110 transition-transform" />
                    <span className="text-[10px] font-mono font-bold">DEHYDRATION</span>
                    <span className="text-[9px] text-slate-400">Seat 13C</span>
                  </button>

                  <button
                    onClick={() => triggerPreset('TURBULENCE')}
                    className="flex flex-col items-center justify-center p-2 rounded-lg bg-purple-500/10 border border-purple-500/30 text-purple-300 hover:bg-purple-500/20 hover:border-purple-500/50 transition-all text-center group"
                  >
                    <Wind className="w-4 h-4 text-purple-400 mb-1 group-hover:scale-110 transition-transform" />
                    <span className="text-[10px] font-mono font-bold">TURBULENCE</span>
                    <span className="text-[9px] text-slate-400">T-12 Sequence</span>
                  </button>

                  <button
                    onClick={() => triggerPreset('LANDING')}
                    className="flex flex-col items-center justify-center p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 hover:bg-emerald-500/20 hover:border-emerald-500/50 transition-all text-center group col-span-2 sm:col-span-1"
                  >
                    <PlaneLanding className="w-4 h-4 text-emerald-400 mb-1 group-hover:scale-110 transition-transform" />
                    <span className="text-[10px] font-mono font-bold">LANDING</span>
                    <span className="text-[9px] text-slate-400">Post-Flight</span>
                  </button>

                </div>
              </div>

            </div>

          </div>
        )}

      </div>
    </div>
  );
};
