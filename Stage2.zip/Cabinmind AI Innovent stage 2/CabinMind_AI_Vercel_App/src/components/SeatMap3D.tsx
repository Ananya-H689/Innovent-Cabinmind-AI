import React from 'react';
import { useCabinSimulation } from '../context/SimulationContext';
import type { SeatStatus } from '../types/cabin';
import { motion } from 'framer-motion';
import { User, Zap } from 'lucide-react';

export const SeatMap3D: React.FC = () => {
  const { seats, selectedSeatId, setSelectedSeatId } = useCabinSimulation();

  const rows = [12, 13, 14, 15, 16, 17];
  const leftLetters = ['A', 'B', 'C'];
  const rightLetters = ['D', 'E', 'F'];

  const getSeatColorClass = (status: SeatStatus, isSelected: boolean) => {
    switch (status) {
      case 'ACTION':
        return isSelected
          ? 'bg-rose-500/30 border-rose-400 text-rose-200 shadow-lg shadow-rose-500/40 ring-2 ring-rose-400'
          : 'bg-rose-950/40 border-rose-500/60 text-rose-300 hover:border-rose-400';
      case 'MONITOR':
        return isSelected
          ? 'bg-amber-500/30 border-amber-400 text-amber-200 shadow-lg shadow-amber-500/40 ring-2 ring-amber-400'
          : 'bg-amber-950/40 border-amber-500/60 text-amber-300 hover:border-amber-400';
      case 'MILD':
        return isSelected
          ? 'bg-yellow-500/30 border-yellow-400 text-yellow-200 shadow-lg shadow-yellow-500/40 ring-2 ring-yellow-400'
          : 'bg-yellow-950/40 border-yellow-500/50 text-yellow-300 hover:border-yellow-400';
      case 'NORMAL':
      default:
        return isSelected
          ? 'bg-cyan-500/30 border-cyan-400 text-cyan-200 shadow-lg shadow-cyan-500/40 ring-2 ring-cyan-400'
          : 'bg-slate-900/60 border-slate-700/80 text-slate-300 hover:border-cyan-500/50 hover:bg-slate-800/80';
    }
  };

  const getStatusBadge = (status: SeatStatus) => {
    switch (status) {
      case 'ACTION':
        return <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />;
      case 'MONITOR':
        return <span className="w-2 h-2 rounded-full bg-amber-400" />;
      case 'MILD':
        return <span className="w-2 h-2 rounded-full bg-yellow-400" />;
      case 'NORMAL':
      default:
        return <span className="w-2 h-2 rounded-full bg-emerald-400" />;
    }
  };

  return (
    <div className="glass-panel rounded-2xl p-6 border border-white/10 relative overflow-hidden">
      <div className="absolute inset-0 bg-grid-pattern opacity-30 pointer-events-none" />
      <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 relative z-10">
        <div>
          <div className="flex items-center space-x-2">
            <h3 className="font-heading text-lg font-bold text-white tracking-wide">
              CABIN DIGITAL TWIN SEAT MAP
            </h3>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">
              36 PASSENGER NODES
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Airbus A320neo Main Cabin (Rows 12–17, 3-3 Configuration)
          </p>
        </div>

        <div className="flex items-center space-x-4 bg-slate-900/80 px-3.5 py-1.5 rounded-lg border border-slate-800 text-[11px] font-mono">
          <div className="flex items-center space-x-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
            <span className="text-slate-300">Normal</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-yellow-400" />
            <span className="text-slate-300">Mild</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
            <span className="text-slate-300">Monitor</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
            <span className="text-rose-300 font-bold">Action</span>
          </div>
        </div>
      </div>

      <div className="flex justify-center mb-6 relative z-10">
        <div className="flex items-center space-x-2 px-4 py-1 rounded-t-xl bg-slate-900/90 border border-cyan-500/30 text-[11px] font-mono text-cyan-400 tracking-wider">
          <Zap className="w-3.5 h-3.5" />
          <span>COCKPIT / FRONT CABIN DIRECTION</span>
        </div>
      </div>

      <div className="relative z-10 max-w-2xl mx-auto bg-slate-950/60 p-6 rounded-3xl border border-slate-800 shadow-2xl">
        
        <div className="absolute left-2 top-0 bottom-0 w-1 bg-gradient-to-b from-cyan-500/20 via-cyan-500/40 to-cyan-500/20 rounded-full opacity-60" />
        <div className="absolute right-2 top-0 bottom-0 w-1 bg-gradient-to-b from-cyan-500/20 via-cyan-500/40 to-cyan-500/20 rounded-full opacity-60" />

        <div className="space-y-4">
          {rows.map((rowNum) => (
            <div key={rowNum} className="flex items-center justify-between gap-2 sm:gap-4">
              
              <div className="grid grid-cols-3 gap-2 flex-1">
                {leftLetters.map((letter) => {
                  const seatId = `${rowNum}${letter}`;
                  const seat = seats.find(s => s.id === seatId);
                  if (!seat) return null;
                  const isSelected = selectedSeatId === seatId;

                  return (
                    <motion.button
                      key={seatId}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.96 }}
                      onClick={() => setSelectedSeatId(seatId)}
                      className={`relative flex flex-col items-center justify-between p-2.5 rounded-xl border transition-all duration-200 min-h-[72px] cursor-pointer ${getSeatColorClass(seat.status, isSelected)}`}
                    >
                      <div className="w-full flex items-center justify-between">
                        <span className="font-mono text-xs font-bold tracking-tight">
                          {seat.id}
                        </span>
                        {getStatusBadge(seat.status)}
                      </div>

                      <div className="my-1 flex items-center justify-center">
                        <User className={`w-4 h-4 ${isSelected ? 'text-white' : 'text-slate-400'}`} />
                      </div>

                      <div className="w-full flex items-center justify-between text-[10px] font-mono">
                        <span className="text-slate-400">{seat.telemetry.heartRate} bpm</span>
                        <span className={`font-semibold ${seat.riskScore > 75 ? 'text-rose-400 font-bold' : seat.riskScore > 50 ? 'text-amber-400' : 'text-cyan-400'}`}>
                          {seat.riskScore}
                        </span>
                      </div>
                    </motion.button>
                  );
                })}
              </div>

              <div className="flex flex-col items-center justify-center w-8 text-[11px] font-mono text-slate-500 font-bold select-none">
                <span>R{rowNum}</span>
                <span className="text-[9px] text-slate-600 font-normal">AISLE</span>
              </div>

              <div className="grid grid-cols-3 gap-2 flex-1">
                {rightLetters.map((letter) => {
                  const seatId = `${rowNum}${letter}`;
                  const seat = seats.find(s => s.id === seatId);
                  if (!seat) return null;
                  const isSelected = selectedSeatId === seatId;

                  return (
                    <motion.button
                      key={seatId}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.96 }}
                      onClick={() => setSelectedSeatId(seatId)}
                      className={`relative flex flex-col items-center justify-between p-2.5 rounded-xl border transition-all duration-200 min-h-[72px] cursor-pointer ${getSeatColorClass(seat.status, isSelected)}`}
                    >
                      <div className="w-full flex items-center justify-between">
                        <span className="font-mono text-xs font-bold tracking-tight">
                          {seat.id}
                        </span>
                        {getStatusBadge(seat.status)}
                      </div>

                      <div className="my-1 flex items-center justify-center">
                        <User className={`w-4 h-4 ${isSelected ? 'text-white' : 'text-slate-400'}`} />
                      </div>

                      <div className="w-full flex items-center justify-between text-[10px] font-mono">
                        <span className="text-slate-400">{seat.telemetry.heartRate} bpm</span>
                        <span className={`font-semibold ${seat.riskScore > 75 ? 'text-rose-400 font-bold' : seat.riskScore > 50 ? 'text-amber-400' : 'text-cyan-400'}`}>
                          {seat.riskScore}
                        </span>
                      </div>
                    </motion.button>
                  );
                })}
              </div>

            </div>
          ))}
        </div>

      </div>

    </div>
  );
};
