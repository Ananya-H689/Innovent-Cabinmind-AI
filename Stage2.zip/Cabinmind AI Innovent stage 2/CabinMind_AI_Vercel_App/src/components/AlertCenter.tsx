import React, { useState } from 'react';
import { useCabinSimulation } from '../context/SimulationContext';
import type { AlertCategory } from '../types/cabin';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Bell, 
  ShieldAlert, 
  AlertTriangle, 
  Info, 
  CheckCircle2, 
  Eye 
} from 'lucide-react';

export const AlertCenter: React.FC = () => {
  const { alerts, acknowledgeAlert, resolveAlert, setSelectedSeatId } = useCabinSimulation();
  const [filterCategory, setFilterCategory] = useState<AlertCategory | 'ALL'>('ALL');

  const filteredAlerts = alerts.filter(a => {
    if (filterCategory === 'ALL') return true;
    return a.category === filterCategory;
  });

  const getCategoryBadge = (category: AlertCategory) => {
    switch (category) {
      case 'CRITICAL':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/50 glow-red';
      case 'HIGH':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/50 glow-amber';
      case 'MONITOR':
        return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/50';
      case 'INFO':
      default:
        return 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50';
    }
  };

  const getCategoryIcon = (category: AlertCategory) => {
    switch (category) {
      case 'CRITICAL':
        return <ShieldAlert className="w-4 h-4 text-rose-400 animate-pulse" />;
      case 'HIGH':
        return <AlertTriangle className="w-4 h-4 text-amber-400" />;
      case 'MONITOR':
        return <AlertTriangle className="w-4 h-4 text-yellow-400" />;
      case 'INFO':
      default:
        return <Info className="w-4 h-4 text-cyan-400" />;
    }
  };

  return (
    <div className="glass-panel rounded-2xl p-6 border border-white/10 space-y-4">
      
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-400/30 text-cyan-400">
            <Bell className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-heading text-lg font-bold text-white tracking-wide flex items-center space-x-2">
              <span>REAL-TIME CABIN ALERT CENTER</span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-mono font-bold border border-rose-400/30">
                {alerts.filter(a => a.status === 'ACTIVE').length} ACTIVE
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              Prioritized edge telemetry anomaly notifications & crew dispatches
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-1 bg-slate-900/80 p-1 rounded-xl border border-slate-800 text-xs font-mono">
          {(['ALL', 'CRITICAL', 'HIGH', 'MONITOR', 'INFO'] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setFilterCategory(cat)}
              className={`px-2.5 py-1 rounded-lg transition-all ${
                filterCategory === cat
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-3 max-h-[420px] overflow-y-auto pr-1">
        <AnimatePresence>
          {filteredAlerts.length === 0 ? (
            <div className="text-center py-8 text-slate-500 text-xs font-mono">
              No active alerts matching filter condition.
            </div>
          ) : (
            filteredAlerts.map((alert) => (
              <motion.div
                key={alert.id}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, height: 0 }}
                className={`p-4 rounded-xl border transition-all duration-200 bg-slate-900/70 ${
                  alert.status === 'RESOLVED' 
                    ? 'opacity-60 border-slate-800 bg-slate-950/40'
                    : 'border-slate-800 hover:border-cyan-500/40'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  
                  <div className="flex items-start space-x-3">
                    <div className="mt-0.5">{getCategoryIcon(alert.category)}</div>
                    <div>
                      <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${getCategoryBadge(alert.category)}`}>
                          {alert.category}
                        </span>
                        <span className="font-mono text-xs font-bold text-cyan-300">
                          SEAT {alert.seatId}
                        </span>
                        <span className="text-xs text-slate-300 font-semibold">
                          ({alert.passengerName})
                        </span>
                        <span className="text-[10px] text-slate-500 font-mono">
                          {alert.timestamp}
                        </span>
                      </div>

                      <h4 className="text-xs font-bold text-slate-100 mt-1">
                        {alert.event}
                      </h4>
                      
                      <p className="text-xs text-slate-400 mt-0.5">
                        <span className="text-slate-500">Action: </span>
                        {alert.recommendedAction}
                      </p>
                    </div>
                  </div>

                  <div className="flex sm:flex-col items-end justify-between sm:justify-start gap-2 border-t sm:border-t-0 border-white/5 pt-2 sm:pt-0">
                    <div className="flex items-center space-x-3 text-[11px] font-mono">
                      <div>
                        <span className="text-slate-500 block text-[9px]">RISK</span>
                        <span className={`font-bold ${alert.riskScore > 75 ? 'text-rose-400' : 'text-amber-400'}`}>
                          {alert.riskScore}/100
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[9px]">CONFIDENCE</span>
                        <span className="text-cyan-300 font-bold">{alert.confidence}%</span>
                      </div>
                    </div>

                    <div className="flex items-center space-x-1.5">
                      {alert.seatId !== 'CABIN' && (
                        <button
                          onClick={() => setSelectedSeatId(alert.seatId)}
                          className="px-2 py-1 rounded bg-slate-800 text-slate-300 hover:bg-slate-700 text-[11px] font-mono flex items-center space-x-1 border border-slate-700"
                        >
                          <Eye className="w-3 h-3 text-cyan-400" />
                          <span>VIEW</span>
                        </button>
                      )}

                      {alert.status === 'ACTIVE' && (
                        <button
                          onClick={() => acknowledgeAlert(alert.id)}
                          className="px-2 py-1 rounded bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 text-[11px] font-mono border border-amber-500/40"
                        >
                          ACK
                        </button>
                      )}

                      {alert.status !== 'RESOLVED' && (
                        <button
                          onClick={() => resolveAlert(alert.id)}
                          className="px-2 py-1 rounded bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 text-[11px] font-mono border border-emerald-500/40 flex items-center space-x-1"
                        >
                          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                          <span>RESOLVE</span>
                        </button>
                      )}
                    </div>
                  </div>

                </div>
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>

    </div>
  );
};
