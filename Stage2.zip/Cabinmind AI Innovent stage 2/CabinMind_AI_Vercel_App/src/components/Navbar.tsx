import React from 'react';
import { useCabinSimulation } from '../context/SimulationContext';
import type { RoutePath } from '../types/cabin';
import { 
  Plane, 
  Activity, 
  User, 
  BarChart3, 
  Cpu, 
  Sliders, 
  Radio, 
  ChevronRight
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const { currentRoute, navigate, flightInfo, isRunning, toggleSimulation, simTimeStr } = useCabinSimulation();

  const navItems: { label: string; path: RoutePath; icon: React.FC<{ className?: string }> }[] = [
    { label: 'Overview', path: '/', icon: Plane },
    { label: 'Crew Command', path: '/crew', icon: Activity },
    { label: 'Passenger View', path: '/passenger', icon: User },
    { label: 'Analytics', path: '/analytics', icon: BarChart3 },
    { label: 'Hardware Twin', path: '/hardware', icon: Cpu },
    { label: 'AI Engine', path: '/engine', icon: Sliders },
  ];

  return (
    <header className="sticky top-0 z-40 w-full glass-panel border-b border-white/10 bg-[#070B14]/80 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => navigate('/')}>
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-600/30 border border-cyan-400/40 shadow-lg shadow-cyan-500/10">
              <Plane className="w-5 h-5 text-cyan-400 transform -rotate-45" />
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
              </span>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-heading text-lg font-bold tracking-wider text-white">CABINMIND</span>
                <span className="text-xs px-1.5 py-0.5 rounded font-mono font-semibold bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">AI</span>
              </div>
              <p className="text-[10px] text-slate-400 font-mono tracking-tight">InnoVent-27 Aerospace Platform</p>
            </div>
          </div>

          <nav className="hidden md:flex items-center space-x-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentRoute === item.path;
              return (
                <button
                  key={item.path}
                  onClick={() => navigate(item.path)}
                  className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs font-medium transition-all duration-200 ${
                    isActive
                      ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-400/40 shadow-sm shadow-cyan-500/20'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          <div className="flex items-center space-x-3">
            <div className="hidden lg:flex items-center space-x-3 bg-slate-900/60 border border-slate-800 rounded-lg px-3 py-1.5 text-xs font-mono">
              <div className="flex items-center space-x-1.5">
                <span className="text-slate-400">FLT:</span>
                <span className="text-cyan-300 font-bold">{flightInfo.flightNumber}</span>
              </div>
              <span className="text-slate-600">|</span>
              <div className="flex items-center space-x-1 text-slate-300">
                <span>{flightInfo.origin.split(' ')[0]}</span>
                <ChevronRight className="w-3 h-3 text-cyan-500" />
                <span>{flightInfo.destination.split(' ')[0]}</span>
              </div>
              <span className="text-slate-600">|</span>
              <div className="text-emerald-400 font-semibold">{simTimeStr}</div>
            </div>

            <div className="flex items-center space-x-2 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-[11px] font-mono font-medium text-emerald-400">
              <Radio className="w-3 h-3 text-emerald-400 animate-pulse" />
              <span>SIMULATION MODE</span>
            </div>

            <button
              onClick={toggleSimulation}
              className={`p-2 rounded-lg border text-xs font-mono transition-colors ${
                isRunning 
                  ? 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-700' 
                  : 'bg-amber-500/20 border-amber-500/40 text-amber-300 hover:bg-amber-500/30'
              }`}
              title={isRunning ? 'Pause Simulation' : 'Resume Simulation'}
            >
              {isRunning ? 'PAUSE' : 'RESUME'}
            </button>
          </div>

        </div>
      </div>
      
      <div className="flex md:hidden overflow-x-auto px-4 py-2 border-t border-white/5 space-x-2 no-scrollbar">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentRoute === item.path;
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap ${
                isActive
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
