import React from 'react';
import { useCabinSimulation } from '../context/SimulationContext';
import { motion } from 'framer-motion';
import { 
  Smile, 
  AlertOctagon, 
  Activity, 
  AlertTriangle, 
  Droplets, 
  CheckCircle2, 
  Brain 
} from 'lucide-react';

export const AnalyticsOverviewCards: React.FC = () => {
  const { seats, alerts } = useCabinSimulation();

  // Compute live metrics from simulation state
  const totalSeats = seats.length || 36;
  const avgComfort = Math.round(seats.reduce((acc, s) => acc + s.comfortScore, 0) / totalSeats);
  const activeRisks = seats.filter(s => s.status === 'ACTION' || s.status === 'MONITOR').length;
  const stressEvents = seats.filter(s => s.wellbeing === 'HIGH STRESS' || s.wellbeing === 'DISTRESS' || s.wellbeing === 'MILD ANXIETY').length;
  const dvtRisks = seats.filter(s => s.wellbeing === 'DVT RISK' || s.dvtScore >= 60).length;
  const hydrationRisks = seats.filter(s => s.wellbeing === 'DEHYDRATION RISK' || s.dehydrationScore >= 60).length;
  const activeInterventions = alerts.filter(a => a.status === 'ACTIVE' || a.status === 'ACKNOWLEDGED').length;
  const avgConfidence = Math.round(seats.reduce((acc, s) => acc + s.confidence, 0) / totalSeats);

  const cards = [
    {
      title: 'CABIN COMFORT',
      value: `${avgComfort}%`,
      icon: Smile,
      color: 'text-cyan-400',
      bg: 'bg-cyan-500/10 border-cyan-500/30',
      glow: 'glow-cyan',
    },
    {
      title: 'ACTIVE RISKS',
      value: String(activeRisks).padStart(2, '0'),
      icon: AlertOctagon,
      color: 'text-rose-400',
      bg: 'bg-rose-500/10 border-rose-500/30',
      glow: 'glow-red',
    },
    {
      title: 'STRESS EVENTS',
      value: String(stressEvents).padStart(2, '0'),
      icon: Activity,
      color: 'text-amber-400',
      bg: 'bg-amber-500/10 border-amber-500/30',
      glow: 'glow-amber',
    },
    {
      title: 'DVT RISKS',
      value: String(dvtRisks).padStart(2, '0'),
      icon: AlertTriangle,
      color: 'text-yellow-400',
      bg: 'bg-yellow-500/10 border-yellow-500/30',
      glow: '',
    },
    {
      title: 'HYDRATION RISKS',
      value: String(hydrationRisks).padStart(2, '0'),
      icon: Droplets,
      color: 'text-blue-400',
      bg: 'bg-blue-500/10 border-blue-500/30',
      glow: '',
    },
    {
      title: 'ACTIVE INTERVENTIONS',
      value: String(activeInterventions).padStart(2, '0'),
      icon: CheckCircle2,
      color: 'text-emerald-400',
      bg: 'bg-emerald-500/10 border-emerald-500/30',
      glow: '',
    },
    {
      title: 'AI CONFIDENCE',
      value: `${avgConfidence}%`,
      icon: Brain,
      color: 'text-purple-400',
      bg: 'bg-purple-500/10 border-purple-500/30',
      glow: '',
    },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
      {cards.map((card, i) => {
        const Icon = card.icon;
        return (
          <motion.div
            key={card.title}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className={`glass-panel p-3.5 rounded-xl border flex flex-col justify-between ${card.bg} ${card.glow}`}
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono font-semibold text-slate-400 uppercase tracking-tight">
                {card.title}
              </span>
              <Icon className={`w-4 h-4 ${card.color}`} />
            </div>

            <div className="mt-2">
              <span className={`text-2xl font-bold font-mono tracking-tight ${card.color}`}>
                {card.value}
              </span>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
};
