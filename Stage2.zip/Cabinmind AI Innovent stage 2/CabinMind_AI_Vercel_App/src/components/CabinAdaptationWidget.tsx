import React from 'react';
import { useCabinSimulation } from '../context/SimulationContext';
import { 
  Sliders, 
  Sun, 
  Wind, 
  Volume2 
} from 'lucide-react';

export const CabinAdaptationWidget: React.FC = () => {
  const { cabinAdaptation, updateCabinAdaptation } = useCabinSimulation();

  return (
    <div className="glass-panel rounded-2xl p-6 border border-white/10 space-y-6">
      
      <div className="flex items-center space-x-3 border-b border-white/10 pb-4">
        <div className="p-2.5 rounded-xl bg-cyan-500/20 border border-cyan-400/30 text-cyan-400">
          <Sliders className="w-5 h-5" />
        </div>
        <div>
          <div className="flex items-center space-x-2">
            <h3 className="font-heading text-lg font-bold text-white tracking-wide">
              STRESS-AWARE CABIN ADAPTATION ENGINE
            </h3>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">
              AUTONOMOUS EDGE CONTROL
            </span>
          </div>
          <p className="text-xs text-slate-400">
            Real-time closed-loop environmental tuning based on aggregated passenger wellbeing states
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-slate-300 flex items-center space-x-1.5">
              <Sun className="w-4 h-4 text-amber-400" />
              <span>CABIN LIGHTING</span>
            </span>
            <span className="text-[10px] font-mono text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
              ACTIVE MODE
            </span>
          </div>

          <div className="text-sm font-bold font-mono text-amber-200 bg-slate-950/80 p-2.5 rounded-lg border border-slate-800">
            {cabinAdaptation.lighting}
          </div>

          <div className="grid grid-cols-2 gap-1.5 text-[11px] font-mono">
            <button
              onClick={() => updateCabinAdaptation({ lighting: 'Warm Comfort Mode (2700K)' })}
              className={`p-1.5 rounded transition-all ${cabinAdaptation.lighting.includes('2700K') ? 'bg-amber-500/30 text-amber-200 border border-amber-400/50' : 'bg-slate-800 text-slate-400 hover:text-slate-200'}`}
            >
              Warm 2700K
            </button>
            <button
              onClick={() => updateCabinAdaptation({ lighting: 'Circadian Sunset (2200K)' })}
              className={`p-1.5 rounded transition-all ${cabinAdaptation.lighting.includes('Sunset') ? 'bg-amber-500/30 text-amber-200 border border-amber-400/50' : 'bg-slate-800 text-slate-400 hover:text-slate-200'}`}
            >
              Sunset 2200K
            </button>
          </div>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-slate-300 flex items-center space-x-1.5">
              <Wind className="w-4 h-4 text-cyan-400" />
              <span>AIRFLOW & OXYGEN</span>
            </span>
            <span className="text-[10px] font-mono text-cyan-300 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/30">
              OPTIMIZED
            </span>
          </div>

          <div className="text-sm font-bold font-mono text-cyan-200 bg-slate-950/80 p-2.5 rounded-lg border border-slate-800">
            {cabinAdaptation.airflow}
          </div>

          <div className="grid grid-cols-2 gap-1.5 text-[11px] font-mono">
            <button
              onClick={() => updateCabinAdaptation({ airflow: '+8% Oxygen Balance' })}
              className={`p-1.5 rounded transition-all ${cabinAdaptation.airflow.includes('+8%') ? 'bg-cyan-500/30 text-cyan-200 border border-cyan-400/50' : 'bg-slate-800 text-slate-400 hover:text-slate-200'}`}
            >
              +8% Oxygen
            </button>
            <button
              onClick={() => updateCabinAdaptation({ airflow: '+12% Cool Circulation' })}
              className={`p-1.5 rounded transition-all ${cabinAdaptation.airflow.includes('+12%') ? 'bg-cyan-500/30 text-cyan-200 border border-cyan-400/50' : 'bg-slate-800 text-slate-400 hover:text-slate-200'}`}
            >
              +12% Cool
            </button>
          </div>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-slate-300 flex items-center space-x-1.5">
              <Volume2 className="w-4 h-4 text-purple-400" />
              <span>CALMING AUDIO & SAFETY</span>
            </span>
            <span className="text-[10px] font-mono text-purple-300 bg-purple-500/10 px-2 py-0.5 rounded border border-purple-500/30">
              AUDIO 432Hz
            </span>
          </div>

          <div className="text-sm font-bold font-mono text-purple-200 bg-slate-950/80 p-2.5 rounded-lg border border-slate-800 flex items-center justify-between">
            <span>{cabinAdaptation.audio}</span>
            <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              CREW: {cabinAdaptation.crewReadiness}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-1.5 text-[11px] font-mono">
            <button
              onClick={() => updateCabinAdaptation({ audio: 'Ambient Calming 432Hz' })}
              className={`p-1.5 rounded transition-all ${cabinAdaptation.audio.includes('432Hz') ? 'bg-purple-500/30 text-purple-200 border border-purple-400/50' : 'bg-slate-800 text-slate-400 hover:text-slate-200'}`}
            >
              432Hz Binaural
            </button>
            <button
              onClick={() => updateCabinAdaptation({ crewReadiness: cabinAdaptation.crewReadiness === 'ELEVATED' ? 'STANDARD' : 'ELEVATED' })}
              className={`p-1.5 rounded transition-all ${cabinAdaptation.crewReadiness === 'ELEVATED' ? 'bg-emerald-500/30 text-emerald-200 border border-emerald-400/50' : 'bg-slate-800 text-slate-400 hover:text-slate-200'}`}
            >
              Toggle Crew Alert
            </button>
          </div>
        </div>

      </div>

    </div>
  );
};
