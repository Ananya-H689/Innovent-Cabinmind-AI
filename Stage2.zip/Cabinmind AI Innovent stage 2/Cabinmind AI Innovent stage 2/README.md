# CabinMind AI - InnoVent-27 Stage 2 Submission (Team Hustle Squad)

**Start here:** watch `CabinMind_AI_Stage2_Demo_Video.mp4` (2 min 39 s), then open `CabinMind_AI_Premium_App.html` in a browser.

| What | Where | Status |
|---|---|---|
| Crew app + passenger companion + 3D cabin twin | CabinMind_AI_Premium_App.html, passenger interaction.html | Working simulation |
| Hardware simulator (4 sensors -> ESP32 -> LED/tone) | Cabinmind ai Hardware prototype/ | Working simulation |
| Wiring schematic, breadboard, 3D assembly | Hardware prototype/ + Model Training folder | Designed |
| Risk model (90.3% acc, 86.4% macro F1) + intent model (77.3%) | Cabinmind AI Model Training-Risk classification/ | Trained (synthetic data) |
| ESP32 firmware | Cabinmind AI AWS FULL/ESP32_SensorRig/ | Written, not yet flashed |
| AWS pipeline (IoT Core > Lambda > DynamoDB > API) | Cabinmind AI AWS FULL/aws/ | Code unit-tested, deployment next |
| Pitch deck | Cabinmind AI AWS FULL/aws/CabinMind_AI_Pitch_Deck.pptx | Ready |
| Budget, fit, societal impact | PDFs in this folder | Ready |

**Honesty note:** sensors and cloud are simulated at Stage 2. Physical rig + live AWS are the Stage 3 plan.
