# CabinMind AI — Risk Classifier: Real Training Results

**Model:** Random Forest Classifier (200 trees, max depth 8)
**Dataset:** 6,000 synthetic passenger readings (heart rate, GSR, movement, cabin temp, ambient noise) generated to mirror realistic seat-sensor distributions, split 80/20 train/test, stratified by risk class.

## Headline Results
- **Test Accuracy: 90.3%**
- **Macro F1-score: 86.4%**

## Full Classification Report
```
              precision    recall  f1-score   support

    critical      0.873     0.833     0.853        66
      normal      0.972     0.932     0.952       754
     warning      0.839     0.904     0.870       167
       watch      0.748     0.822     0.783       213

    accuracy                          0.903      1200
   macro avg      0.858     0.873     0.864      1200
weighted avg      0.908     0.903     0.905      1200

```

## Confusion Matrix
```
Rows = actual, Columns = predicted, order: normal / watch / warning / critical
[[703  51   0   0]
 [ 20 175  18   0]
 [  0   8 151   8]
 [  0   0  11  55]]
```
See `confusion_matrix.png` for the visual version.

## Feature Importance
See `feature_importance.png` — shows which sensor signal the model actually
relies on most to make its prediction (useful for the Explainability feature
in the live dashboard).

## Files in this folder
- `cabinmind_training_dataset.csv` — the full 6,000-row training dataset
- `confusion_matrix.png`
- `feature_importance.png`
- `model_results_report.md` — this file

This is a genuine trained scikit-learn model run on synthetic data standing
in for real sensor readings — the same algorithm family (Random Forest) named
in the AWS SageMaker plan. Swapping in real sensor logs later (once hardware
exists) is a drop-in dataset replacement, not an architecture change.
