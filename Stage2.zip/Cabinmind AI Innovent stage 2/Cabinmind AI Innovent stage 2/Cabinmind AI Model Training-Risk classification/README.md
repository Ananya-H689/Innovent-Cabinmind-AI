# CabinMind Copilot — Trained Intent Model

This is a genuinely trained model, not hardcoded if/else rules:
**TF-IDF vectorizer + multinomial Logistic Regression**, trained on 144
example crew questions across 8 intents (seat_lookup, turbulence,
check_seats, briefing, dvt, fatigue, greeting, other).

- Held-out test accuracy: **77.3%** on questions the model never saw during training
  (small dataset, honestly reported — grows fast with more logged real crew questions later)
- `intent_model.json` — the exported vocabulary, IDF weights, and Logistic
  Regression coefficients, small enough (~15KB) to run entirely in the
  browser with no internet connection or API key needed
- Already embedded and wired into `CabinMind_AI_Premium_App.html`'s Copilot chat —
  every question typed is classified by this real trained model before a
  response is generated from the live cabin data

To retrain with more examples later: add more phrasings to the intent training data and re-export `intent_model.json` in this same JSON format.
