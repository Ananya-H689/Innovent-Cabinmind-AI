import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

BG, PANEL, TEAL, AMBER, TXT, MUTED = "#0B1F2E", "#12324A", "#2EC4B6", "#FFB703", "#FFFFFF", "#9FB8C8"
fig, ax = plt.subplots(figsize=(16, 9), dpi=120)
fig.patch.set_facecolor(BG); ax.set_facecolor(BG)
ax.set_xlim(0, 160); ax.set_ylim(0, 90); ax.axis("off")

def box(x, y, w, h, title, sub="", color=TEAL, fill=PANEL):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.4,rounding_size=1.5",
                                fc=fill, ec=color, lw=2))
    ax.text(x + w/2, y + h/2 + (1.6 if sub else 0), title, ha="center", va="center",
            color=TXT, fontsize=13, fontweight="bold")
    if sub:
        ax.text(x + w/2, y + h/2 - 2.6, sub, ha="center", va="center", color=MUTED, fontsize=9.5)

def arrow(x1, y1, x2, y2, label="", color=TEAL, style="-|>", ls="-", lx=0, ly=1.8):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle=style, mutation_scale=18,
                                 color=color, lw=2, linestyle=ls))
    if label:
        ax.text((x1+x2)/2 + lx, (y1+y2)/2 + ly, label, ha="center", color=color, fontsize=9.5)

ax.text(80, 85, "CabinMind AI - System Architecture", ha="center", color=TXT, fontsize=22, fontweight="bold")
ax.text(80, 81, "Edge AI at the seat  |  AWS cloud pipeline  |  Crew dashboard", ha="center", color=MUTED, fontsize=12)

# Layer labels
ax.text(3, 71, "SEAT UNIT (EDGE)", color=AMBER, fontsize=11, fontweight="bold")
ax.text(3, 40, "AWS CLOUD", color=AMBER, fontsize=11, fontweight="bold")

# Edge row
box(3, 56, 34, 12, "4 Sensors", "MAX30102 | GSR | FSR-402 | MPU-6050")
box(50, 56, 38, 12, "ESP32 - Edge AI", "sensor fusion + risk score + state", color=AMBER)
box(101, 56, 30, 12, "Adapt outputs", "WS2812 light + calming tone")
arrow(37.5, 62, 49.5, 62, "I2C / ADC")
arrow(88.5, 62, 100.5, 62, "state")

# SageMaker
box(124, 33, 33, 11, "Amazon SageMaker", "trains Random Forest + intent model", color="#9B8CFF")
arrow(140, 44.8, 78, 55.4, "trained model exported to edge", color="#9B8CFF", ls="--", lx=17, ly=2.6)

# Cloud row
w, h, y = 24, 11, 22
xs = [3, 31, 59, 87]
box(xs[0], y, w, h, "AWS IoT Core", "MQTT over TLS")
box(xs[1], y, w, h, "Lambda: ingest", "validate + strip raw")
box(xs[2], y, w, h, "DynamoDB", "latest state, 24 h TTL")
box(xs[3], y, w, h, "Lambda: read", "latest seat state")
for i in range(3):
    arrow(xs[i]+w+0.6, y+h/2, xs[i+1]-0.6, y+h/2)
ax.text(xs[0]+w+1.7, y+h+2, "IoT rule", ha="center", color=TEAL, fontsize=9)

# Second row: API Gateway + dashboard (under Lambda: read)
box(87, 4, 24, 11, "API Gateway", "GET /seats/{seatId}")
box(121, 4, 36, 11, "Crew Dashboard", "Seat 1A live + 23 simulated", color=AMBER)
arrow(99, y-0.6, 99, 15.7, "")
arrow(111.6, 9.5, 120.4, 9.5, "fetch()", ly=2.2)

# Edge -> cloud publish
arrow(69, 55.4, 15, 33.8, "MQTT publish: state only (no raw biometrics)", lx=-4, ly=3.2)
# Consent back-channel
box(3, 4, 24, 11, "Passenger app", "Allow / Stop sharing", color="#9B8CFF")
arrow(15, 15.6, 15, 21.4, "consent", color="#9B8CFF", ls="--", lx=5, ly=-0.4)

plt.savefig("CabinMind_AWS_Architecture.png", facecolor=BG, bbox_inches="tight", pad_inches=0.3)
