-- AWS IoT Core > Message routing > Rules > Create rule
-- Name: CabinMindSeatStateToLambda     Action: Lambda -> cabinmind-ingest
SELECT * FROM 'cabinmind/+/seat/+/state'
