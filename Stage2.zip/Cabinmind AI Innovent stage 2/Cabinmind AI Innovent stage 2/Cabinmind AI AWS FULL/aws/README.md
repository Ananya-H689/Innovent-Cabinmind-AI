# CabinMind AWS Pipeline (Stage 2)

`ESP32 -> IoT Core (MQTT/TLS) -> IoT Rule -> Lambda ingest -> DynamoDB -> Lambda read -> API Gateway -> Dashboard`

See `CabinMind_AWS_Architecture.png`. All services fit inside the free tier / InnoVent credits.

## Files
| File | Purpose |
|---|---|
| `lambda_ingest.py` | IoT Rule target. Validates the message, **strips any raw biometric fields**, adds server time + 24 h TTL, writes to DynamoDB |
| `lambda_get_state.py` | Behind API Gateway. Returns the latest classified state for a seat (`offline` if no data for 15 s) |
| `iot_rule.sql` | IoT Rule query: `SELECT * FROM 'cabinmind/+/seat/+/state'` |
| `test_event.json` | Sample message - paste into the Lambda test tab or the MQTT test client |
| `test_lambdas.py` | Offline unit tests (`python test_lambdas.py`) - already passing |
| `make_diagram.py` | Regenerates the architecture PNG |

## Deploy steps (about 30 min)
1. **DynamoDB**: create table `CabinMindSeatState`, partition key `seatKey` (String), sort key `ts` (Number). Enable **TTL** on attribute `expiresAt`.
2. **Lambda ingest**: new Python 3.12 function `cabinmind-ingest`, paste `lambda_ingest.py`, give its role `dynamodb:PutItem` on the table.
3. **IoT Core**: create a Thing `cabinmind-seat-1A`, download its certificate, private key and Amazon Root CA, attach a policy allowing `iot:Connect`, `iot:Publish`, `iot:Subscribe`, `iot:Receive` for `cabinmind/*` and client id `cabinmind-seat-*`.
4. **IoT Rule**: create a rule with the query in `iot_rule.sql`, action = Lambda `cabinmind-ingest`.
5. **Lambda read**: function `cabinmind-read`, paste `lambda_get_state.py`, role needs `dynamodb:Query`. Create an **HTTP API** route `GET /seats/{seatId}` pointing to it, CORS on.
6. **Test with fake data (no hardware)**: in IoT Core > MQTT test client, publish `test_event.json` to `cabinmind/DEMO-SFO-NRT/seat/1A/state`. A new item should appear in DynamoDB, and `GET <api-url>/seats/1A` should return `"state":"warning"`.
7. **Firmware**: copy `secrets_template.h` to `secrets.h`, paste the endpoint and certificates, flash `ESP32_SensorRig.ino`.

## Dashboard hook (Seat 1A goes live)
```js
async function pollSeat1A() {
  try {
    const r = await fetch("https://YOUR-API-ID.execute-api.REGION.amazonaws.com/seats/1A");
    const s = await r.json();               // {state, riskScore, stillness, occupied, stale}
    updateSeatTile("1A", s.state, s.riskScore);   // use your dashboard's existing tile function
  } catch (e) { /* keep last simulated value */ }
}
setInterval(pollSeat1A, 2000);
```

## Privacy notes (matches the Societal Impact PDF)
- Firmware publishes only `state, riskScore, stillness, occupied` - raw HR/GSR/movement stay on the ESP32.
- `lambda_ingest.py` drops any `raw_*` field even if a bench build sends one.
- DynamoDB TTL deletes session data after 24 h (set `TTL_HOURS` to your flight length).
- Consent: the passenger app publishes `{"allow":false}` to `.../consent`; the firmware stops publishing immediately.
