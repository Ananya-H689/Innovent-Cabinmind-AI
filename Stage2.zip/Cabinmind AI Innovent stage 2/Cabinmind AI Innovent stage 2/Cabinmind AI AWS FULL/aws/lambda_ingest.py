"""
CabinMind AI - Lambda: ingest seat state from AWS IoT Core -> DynamoDB.

Triggered by an IoT Rule (see iot_rule.sql). Receives the classified seat state
published by the ESP32 and stores it. Privacy by design: any raw biometric
field (raw_*, heart rate, GSR...) is stripped before anything is written.

Env vars:  TABLE_NAME (default CabinMindSeatState), TTL_HOURS (default 24)
Table:     partition key seatKey (S), sort key ts (N, epoch ms)
"""
import json
import os
import time
from decimal import Decimal


TABLE_NAME = os.environ.get("TABLE_NAME", "CabinMindSeatState")
TTL_HOURS = int(os.environ.get("TTL_HOURS", "24"))     # session data auto-deleted ("deleted at landing")
VALID_STATES = {"vacant", "normal", "watch", "warning", "critical"}
ALLOWED_FIELDS = {"flightId", "seatId", "state", "riskScore", "stillness", "occupied"}

_table = None


def _get_table():
    global _table
    if _table is None:
        import boto3   # available by default in the Lambda runtime
        _table = boto3.resource("dynamodb").Table(TABLE_NAME)
    return _table


def build_item(event, now_ms=None):
    """Validate + sanitise one MQTT message into a DynamoDB item. Raises ValueError if bad."""
    if not isinstance(event, dict):
        raise ValueError("payload must be a JSON object")

    clean = {k: v for k, v in event.items() if k in ALLOWED_FIELDS}   # drops raw_* and unknown keys
    for required in ("flightId", "seatId", "state"):
        if required not in clean:
            raise ValueError(f"missing field: {required}")
    if clean["state"] not in VALID_STATES:
        raise ValueError(f"invalid state: {clean['state']}")

    risk = int(clean.get("riskScore", 0))
    if not 0 <= risk <= 100:
        raise ValueError("riskScore out of range")

    now_ms = now_ms or int(time.time() * 1000)
    return {
        "seatKey": f"{clean['flightId']}#{clean['seatId']}",
        "ts": now_ms,                                   # server-side time (device only has uptime)
        "flightId": clean["flightId"],
        "seatId": clean["seatId"],
        "state": clean["state"],
        "riskScore": risk,
        "stillness": bool(clean.get("stillness", False)),
        "occupied": bool(clean.get("occupied", False)),
        "expiresAt": int(now_ms / 1000) + TTL_HOURS * 3600,   # DynamoDB TTL attribute
    }


def lambda_handler(event, context):
    try:
        item = build_item(event)
    except (ValueError, TypeError) as err:
        print(f"REJECTED payload: {err} | {json.dumps(event)[:300]}")
        return {"statusCode": 400, "body": str(err)}

    _get_table().put_item(Item=item)
    print(f"stored {item['seatKey']} state={item['state']} risk={item['riskScore']}")
    return {"statusCode": 200, "body": "ok"}
