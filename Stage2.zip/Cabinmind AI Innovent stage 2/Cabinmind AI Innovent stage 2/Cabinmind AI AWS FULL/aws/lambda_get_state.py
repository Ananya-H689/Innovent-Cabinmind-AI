"""
CabinMind AI - Lambda: read latest seat state for the crew dashboard.
Behind API Gateway (HTTP API):  GET /seats/{seatId}?flightId=DEMO-SFO-NRT
Returns only the classified state - never raw readings.
"""
import json
import os
import time
from decimal import Decimal


TABLE_NAME = os.environ.get("TABLE_NAME", "CabinMindSeatState")
STALE_AFTER_S = int(os.environ.get("STALE_AFTER_S", "15"))   # no data for 15 s -> seat greyed out
DEFAULT_FLIGHT = os.environ.get("DEFAULT_FLIGHT", "DEMO-SFO-NRT")
CORS = {"Access-Control-Allow-Origin": "*", "Content-Type": "application/json"}

_table = None


def _get_table():
    global _table
    if _table is None:
        import boto3   # available by default in the Lambda runtime
        _table = boto3.resource("dynamodb").Table(TABLE_NAME)
    return _table


def _json_default(o):
    if isinstance(o, Decimal):
        return int(o) if o == o.to_integral_value() else float(o)
    raise TypeError


def shape_response(item, now_ms=None):
    now_ms = now_ms or int(time.time() * 1000)
    if not item:
        return {"seatId": None, "state": "offline", "stale": True}
    age_s = (now_ms - int(item["ts"])) / 1000
    stale = age_s > STALE_AFTER_S
    return {
        "seatId": item["seatId"],
        "state": "offline" if stale else item["state"],
        "riskScore": int(item["riskScore"]),
        "stillness": bool(item["stillness"]),
        "occupied": bool(item["occupied"]),
        "ageSeconds": round(age_s, 1),
        "stale": stale,
    }


def lambda_handler(event, context):
    params = event.get("queryStringParameters") or {}
    path = event.get("pathParameters") or {}
    seat_id = path.get("seatId", "1A")
    flight_id = params.get("flightId", DEFAULT_FLIGHT)

    from boto3.dynamodb.conditions import Key   # imported here so tests run without boto3
    res = _get_table().query(
        KeyConditionExpression=Key("seatKey").eq(f"{flight_id}#{seat_id}"),
        ScanIndexForward=False,   # newest first
        Limit=1,
    )
    items = res.get("Items", [])
    body = shape_response(items[0] if items else None)
    if not items:
        body["seatId"] = seat_id
    return {"statusCode": 200, "headers": CORS, "body": json.dumps(body, default=_json_default)}
