"""Offline tests - no AWS needed.  Run:  python test_lambdas.py"""
import json
import lambda_ingest as ing
import lambda_get_state as get

now = 1_800_000_000_000

# 1. good message -> item, raw fields stripped
evt = json.load(open("test_event.json"))
evt["raw_hr"] = 111          # must never reach the database
item = ing.build_item(evt, now_ms=now)
assert item["seatKey"] == "DEMO-SFO-NRT#1A" and item["state"] == "warning"
assert not any(k.startswith("raw") for k in item), "raw biometric data leaked!"
assert item["expiresAt"] == now // 1000 + 24 * 3600

# 2. bad messages rejected
for bad in ({"seatId": "1A"}, {**evt, "state": "panic"}, {**evt, "riskScore": 500}, "nope"):
    try:
        ing.build_item(bad); raise SystemExit(f"should have rejected {bad}")
    except (ValueError, TypeError):
        pass

# 3. dashboard response: fresh vs stale vs empty
assert get.shape_response(item, now_ms=now + 5_000)["state"] == "warning"
assert get.shape_response(item, now_ms=now + 60_000)["state"] == "offline"
assert get.shape_response(None)["state"] == "offline"
print("All Lambda tests passed")
