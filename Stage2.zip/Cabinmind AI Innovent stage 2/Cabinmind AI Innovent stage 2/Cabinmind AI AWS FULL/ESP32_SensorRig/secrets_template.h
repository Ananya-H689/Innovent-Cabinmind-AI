// Copy this file to secrets.h and fill it in. NEVER commit secrets.h to GitHub.
#pragma once
#define WIFI_SSID        "your-wifi-name"
#define WIFI_PASSWORD    "your-wifi-password"
#define AWS_IOT_ENDPOINT "xxxxxxxxxxxxxx-ats.iot.ap-south-1.amazonaws.com"  // IoT Core > Settings

// Amazon Root CA 1 (download from AWS docs) - paste between the markers
static const char AWS_ROOT_CA[] = R"EOF(
-----BEGIN CERTIFICATE-----
...
-----END CERTIFICATE-----
)EOF";

// Device certificate (xxxx-certificate.pem.crt from IoT Core > Create thing)
static const char DEVICE_CERT[] = R"EOF(
-----BEGIN CERTIFICATE-----
...
-----END CERTIFICATE-----
)EOF";

// Device private key (xxxx-private.pem.key) - AWS shows it only once at creation
static const char DEVICE_PRIVATE_KEY[] = R"EOF(
-----BEGIN RSA PRIVATE KEY-----
...
-----END RSA PRIVATE KEY-----
)EOF";
