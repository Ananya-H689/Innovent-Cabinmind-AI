/*
 * CabinMind AI - ESP32 Seat Sensor Rig (single-seat PoC, Seat 1A)
 * InnoVent-27 | Team Hustle Squad
 *
 * Sensors : MAX30102 (heart rate), GSR module (skin response),
 *           FSR-402 (seat pressure / occupancy), MPU-6050 (movement)
 * Outputs : WS2812 LED strip (adaptive light), buzzer (calming tone)
 * Edge AI : sensor fusion + risk score + state classification ON the ESP32
 * Cloud   : AWS IoT Core over MQTT/TLS - publishes ONLY the classified state
 *           (privacy-first: raw biometric values never leave the seat unit)
 *
 * Classification rules mirror CabinMind_Hardware_Simulator.html
 * (hr>100 | gsr>3.2 -> critical, gsr>2.6 | hr>90 -> warning, stillness -> warning),
 * plus a "watch" band to match the 4-class Random Forest labels.
 *
 * Libraries (Arduino Library Manager):
 *   SparkFun MAX3010x Pulse and Proximity Sensor Library
 *   Adafruit MPU6050 (+ Adafruit Unified Sensor, Adafruit BusIO)
 *   Adafruit NeoPixel
 *   PubSubClient
 *   ArduinoJson (v7; on v6 replace JsonDocument with StaticJsonDocument<256>)
 * Board: "ESP32 Dev Module" (esp32 Arduino core 2.x - uses ledcSetup/ledcAttachPin)
 *
 * WIRING
 *   I2C bus (shared): SDA=GPIO21, SCL=GPIO22 -> MAX30102 (0x57) + MPU-6050 (0x68), 3V3
 *   GSR signal  -> GPIO34 (ADC1)      FSR-402 + 10k divider -> GPIO35 (ADC1)
 *   WS2812 DIN  -> GPIO13 (via 330R)  Buzzer (+)            -> GPIO14
 *   NOTE: use ADC1 pins only (32-39); ADC2 stops working while Wi-Fi is on.
 *   Pins follow CabinMind_Wiring_Schematic.png (outputs on GPIO13/GPIO14).
 *   Confirm which of the two is LED vs buzzer when you wire the real rig.
 */

#include <Wire.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <Adafruit_NeoPixel.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include "MAX30105.h"
#include "heartRate.h"
#include "secrets.h"          // Wi-Fi + AWS IoT endpoint + certificates (copy secrets_template.h)

// ---------------- Config ----------------
#define SEAT_ID            "1A"
#define FLIGHT_ID          "DEMO-SFO-NRT"
#define PIN_GSR            34
#define PIN_FSR            35
#define PIN_LED            13
#define PIN_BUZZER         14
#define LED_COUNT          8
#define BUZZER_CH          0

#define PUBLISH_EVERY_MS   2000
#define SENSE_EVERY_MS     100
#define FSR_OCCUPIED_RAW   400       // 12-bit ADC; calibrate with someone sitting
#define FINGER_IR_MIN      50000     // MAX30102 IR below this = no finger on sensor
#define HR_VALID_MS        8000      // heart rate treated as unknown after this
#define STILL_MOVE_IDX     0.05f     // movement index below this = "not moving"
#define STILL_DEMO_MS      20000UL   // demo: 20 s still -> DVT prompt
#define STILL_REAL_MS      (30UL * 60UL * 1000UL)  // real flight: 30 min
#define DEMO_MODE          1         // 1 = short stillness timer for judges
#define PUBLISH_RAW_DEBUG  0         // 1 = also publish raw values (bench testing ONLY)

// MQTT topics
const char* TOPIC_STATE   = "cabinmind/" FLIGHT_ID "/seat/" SEAT_ID "/state";
const char* TOPIC_CONSENT = "cabinmind/" FLIGHT_ID "/seat/" SEAT_ID "/consent";

// ---------------- Globals ----------------
MAX30105 particle;
Adafruit_MPU6050 mpu;
Adafruit_NeoPixel strip(LED_COUNT, PIN_LED, NEO_GRB + NEO_KHZ800);
WiFiClientSecure net;
PubSubClient mqtt(net);

enum RiskState { VACANT, NORMAL, WATCH, WARNING, CRITICAL };
const char* STATE_NAME[] = {"vacant", "normal", "watch", "warning", "critical"};

// heart rate (beat detection)
const byte RATE_SIZE = 4;
byte rates[RATE_SIZE];
byte rateSpot = 0;
long lastBeat = 0;
float hr = 0;                 // smoothed bpm (0 = unknown)
unsigned long lastHrMs = 0;

// slow-moving sensor values
float gsrMicroS = 0;
float moveIdx = 0;            // 0 (still) .. 1 (very active)
bool  occupied = false;
unsigned long stillSinceMs = 0;
bool  stillnessFlag = false;

// Consent: nothing is shared until the passenger taps Allow on the companion screen.
// PoC default is true so the rig demos standalone; the passenger app flips it via MQTT.
bool consentGiven = true;

unsigned long lastSense = 0, lastPublish = 0, lastBeepMs = 0;
RiskState state = VACANT;
int riskScore = 0;

// ---------------- Sensor helpers ----------------
float readGsrMicroSiemens() {
  long sum = 0;
  for (int i = 0; i < 10; i++) { sum += analogRead(PIN_GSR); delay(2); }
  float raw10 = (sum / 10.0f) / 4.0f;                // Grove GSR formula is 10-bit
  if (raw10 >= 510.0f) raw10 = 510.0f;               // avoid divide-by-zero at saturation
  float resistance = ((1024.0f + 2.0f * raw10) * 10000.0f) / (512.0f - raw10);
  return 1000000.0f / resistance;                    // conductance in microsiemens
}

void updateHeartRate() {
  long ir = particle.getIR();
  if (ir < FINGER_IR_MIN) return;                    // no finger on sensor
  if (checkForBeat(ir)) {
    long delta = millis() - lastBeat;
    lastBeat = millis();
    float bpm = 60.0f / (delta / 1000.0f);
    if (bpm > 40 && bpm < 180) {
      rates[rateSpot++ % RATE_SIZE] = (byte)bpm;
      float avg = 0;
      for (byte i = 0; i < RATE_SIZE; i++) avg += rates[i];
      hr = avg / RATE_SIZE;
      lastHrMs = millis();
    }
  }
}

float readMovementIndex() {
  // mean deviation of acceleration magnitude from 1 g over ~10 samples, scaled to 0..1
  sensors_event_t a, g, t;
  float dev = 0;
  for (int i = 0; i < 10; i++) {
    mpu.getEvent(&a, &g, &t);
    float mag = sqrtf(a.acceleration.x * a.acceleration.x +
                      a.acceleration.y * a.acceleration.y +
                      a.acceleration.z * a.acceleration.z);
    dev += fabsf(mag - 9.81f);
    delay(5);
  }
  dev /= 10.0f;
  return constrain(dev / 0.6f, 0.0f, 1.0f);          // 0.6 m/s^2 ~ lively fidgeting; tune on bench
}

// ---------------- Edge AI: classification + risk score ----------------
RiskState classify(float hrNow, float gsr, bool still, bool seatTaken) {
  if (!seatTaken) return VACANT;
  bool hrOk = (hrNow > 0);
  if ((hrOk && hrNow > 100) || gsr > 3.2f) return CRITICAL;
  if ((hrOk && hrNow > 90) || gsr > 2.6f || still) return WARNING;
  if ((hrOk && hrNow > 85) || gsr > 2.4f) return WATCH;
  return NORMAL;
}

int computeRisk(float hrNow, float gsr, float mv) {
  float h = (hrNow > 0) ? hrNow : 70.0f;             // neutral value until a pulse is found
  float r = (h - 60.0f) * 1.5f + gsr * 10.0f + (1.0f - mv) * 10.0f;
  return constrain((int)roundf(r), 0, 100);
}

// ---------------- "Adapt" outputs ----------------
void setLed(uint8_t r, uint8_t g, uint8_t b) {
  for (int i = 0; i < LED_COUNT; i++) strip.setPixelColor(i, strip.Color(r, g, b));
  strip.show();
}

void adaptOutputs(RiskState s) {
  switch (s) {
    case VACANT:   setLed(0, 0, 0);     break;
    case NORMAL:   setLed(0, 120, 90);  break;       // calm teal
    case WATCH:    setLed(80, 120, 0);  break;       // soft lime
    case WARNING:  setLed(200, 110, 0); break;       // amber
    case CRITICAL: setLed(220, 20, 20); break;       // red
  }
  // Calming tone: gentle, never alarming, rate-limited
  unsigned long now = millis();
  if (s == WARNING && now - lastBeepMs > 10000) {
    ledcWriteTone(BUZZER_CH, 523); delay(120); ledcWriteTone(BUZZER_CH, 0);
    lastBeepMs = now;
  } else if (s == CRITICAL && now - lastBeepMs > 4000) {
    ledcWriteTone(BUZZER_CH, 440); delay(200); ledcWriteTone(BUZZER_CH, 0);
    delay(100);
    ledcWriteTone(BUZZER_CH, 440); delay(200); ledcWriteTone(BUZZER_CH, 0);
    lastBeepMs = now;
  }
}

// ---------------- Cloud ----------------
void onMqtt(char* topic, byte* payload, unsigned int len) {
  if (String(topic) != TOPIC_CONSENT) return;
  JsonDocument doc;
  if (deserializeJson(doc, payload, len)) return;
  consentGiven = doc["allow"] | false;               // {"allow":false} = "Stop sharing & delete"
  Serial.printf("[consent] allow=%d\n", consentGiven);
}

void connectWifi() {
  if (WiFi.status() == WL_CONNECTED) return;
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("[wifi] connecting");
  for (int i = 0; i < 40 && WiFi.status() != WL_CONNECTED; i++) { delay(500); Serial.print("."); }
  Serial.println(WiFi.status() == WL_CONNECTED ? " OK" : " FAILED");
}

void connectMqtt() {
  if (mqtt.connected() || WiFi.status() != WL_CONNECTED) return;
  Serial.print("[mqtt] connecting to AWS IoT... ");
  if (mqtt.connect("cabinmind-seat-" SEAT_ID)) {
    mqtt.subscribe(TOPIC_CONSENT);
    Serial.println("OK");
  } else {
    Serial.printf("failed rc=%d\n", mqtt.state());
  }
}

void publishState() {
  if (!consentGiven || !mqtt.connected()) return;
  JsonDocument doc;
  doc["flightId"]  = FLIGHT_ID;
  doc["seatId"]    = SEAT_ID;
  doc["state"]     = STATE_NAME[state];
  doc["riskScore"] = riskScore;
  doc["stillness"] = stillnessFlag;
  doc["occupied"]  = occupied;
  doc["ts"]        = (uint32_t)(millis() / 1000);    // seconds since boot; cloud adds real time
#if PUBLISH_RAW_DEBUG
  doc["raw_hr"] = hr; doc["raw_gsr"] = gsrMicroS; doc["raw_move"] = moveIdx;
#endif
  char buf[256];
  size_t n = serializeJson(doc, buf);
  mqtt.publish(TOPIC_STATE, (const uint8_t*)buf, n);
}

// ---------------- Arduino entry points ----------------
void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);
  analogReadResolution(12);

  strip.begin();
  strip.setBrightness(80);
  setLed(0, 0, 40);
  ledcSetup(BUZZER_CH, 2000, 8);
  ledcAttachPin(PIN_BUZZER, BUZZER_CH);

  if (!particle.begin(Wire, I2C_SPEED_FAST)) {
    Serial.println("[ERR] MAX30102 not found - check wiring");
  } else {
    particle.setup();
    particle.setPulseAmplitudeRed(0x0A);
    particle.setPulseAmplitudeGreen(0);
  }

  if (!mpu.begin()) {
    Serial.println("[ERR] MPU-6050 not found - check wiring");
  } else {
    mpu.setAccelerometerRange(MPU6050_RANGE_4_G);
    mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);
  }

  net.setCACert(AWS_ROOT_CA);
  net.setCertificate(DEVICE_CERT);
  net.setPrivateKey(DEVICE_PRIVATE_KEY);
  mqtt.setServer(AWS_IOT_ENDPOINT, 8883);
  mqtt.setCallback(onMqtt);

  connectWifi();
  Serial.println("CabinMind seat rig ready.");
}

void loop() {
  unsigned long now = millis();

  updateHeartRate();                                 // runs every loop so beat detection stays accurate

  if (now - lastSense >= SENSE_EVERY_MS) {
    lastSense = now;

    occupied  = analogRead(PIN_FSR) > FSR_OCCUPIED_RAW;
    gsrMicroS = readGsrMicroSiemens();
    moveIdx   = readMovementIndex();

    if (now - lastHrMs > HR_VALID_MS) hr = 0;        // stale pulse -> unknown

    // stillness timer (DVT prompt)
    unsigned long stillLimit = DEMO_MODE ? STILL_DEMO_MS : STILL_REAL_MS;
    if (occupied && moveIdx < STILL_MOVE_IDX) {
      if (stillSinceMs == 0) stillSinceMs = now;
      stillnessFlag = (now - stillSinceMs) > stillLimit;
    } else {
      stillSinceMs = 0;
      stillnessFlag = false;
    }

    state     = classify(hr, gsrMicroS, stillnessFlag, occupied);
    riskScore = (state == VACANT) ? 0 : computeRisk(hr, gsrMicroS, moveIdx);
    adaptOutputs(state);

    Serial.printf("HR %.0f | GSR %.2f uS | MOVE %.2f | OCC %d | RISK %d | %s%s\n",
                  hr, gsrMicroS, moveIdx, occupied, riskScore, STATE_NAME[state],
                  stillnessFlag ? " | STILLNESS PROMPT" : "");
  }

  connectWifi();
  connectMqtt();
  mqtt.loop();

  if (now - lastPublish >= PUBLISH_EVERY_MS) {
    lastPublish = now;
    publishState();
  }
}
